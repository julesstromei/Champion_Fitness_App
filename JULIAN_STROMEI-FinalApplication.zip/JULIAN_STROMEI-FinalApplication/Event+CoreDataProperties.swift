//
//  Event+CoreDataProperties.swift
//  STROMEI_ASSIGNMENT
//
//  Created by user185645 on 6/6/21.
//
//

import Foundation
import CoreData


extension Event {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Event> {
        return NSFetchRequest<Event>(entityName: "Event")
    }

    @NSManaged public var eventDate: String? // date is stored as a string as it is interpreted in different formats by different parts of the app
    @NSManaged public var eventDescription: String?
    @NSManaged public var eventName: String?
    @NSManaged public var eventLocation: Location?

}

extension Event : Identifiable {

}
