//
//  STROMEI_ASSIGNMENT_Testing.swift
//  STROMEI_ASSIGNMENT_Testing
//
//  Created by user185645 on 6/15/21.
//

import XCTest
import UIKit

class STROMEI_ASSIGNMENT_Testing: XCTestCase {
    // create link to utilities class
    var passwordTester: Utilities?
    
    override func setUpWithError() throws {
   
    }
    
    override func tearDownWithError() throws {
        passwordTester = nil
    }
    
    //MARK: Test isPaswordValid validation rule
    func testCorrectPassword() throws {
    
        XCTAssertTrue(Utilities.isPasswordValid("PASsword123?"), "Password follows authentication rules")
    }

    func testPasswordEightCharacters() throws {

        XCTAssertFalse(Utilities.isPasswordValid("eightletters"))
    }

    func testPasswordNumbers() throws {

        XCTAssertFalse(Utilities.isPasswordValid("eightletters123"))
    }

    func testSpcialCharacters() throws {

        XCTAssertTrue(Utilities.isPasswordValid("eightletters?"))
    }

    func testCapitalCharacters() throws {

        XCTAssertFalse(Utilities.isPasswordValid("rs123?"))
    }


}
