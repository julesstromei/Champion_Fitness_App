//
//  ChatMessage.swift
//  FIT3178-W08-LabAlternateSolution
//
//  Created by Joshua Olsen on 24/4/21.
//

import UIKit
import MessageKit

// constructs a message to send through messageKit 
class Message: MessageType {
    var sender: SenderType
    var messageId: String
    var sentDate: Date
    var kind: MessageKind
    
    init(sender: Sender, messageId: String, sentDate: Date, message: String) {
        self.sender = sender
        self.messageId = messageId
        self.sentDate = sentDate
        self.kind = .text(message)
    }
}


