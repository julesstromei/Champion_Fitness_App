//
//  Weather.swift
//  Weather
//
//  Created by Mohammad Shayan on 4/16/20.
//  Copyright © 2020 Mohammad Shayan. All rights reserved.
// sourced from: https://github.com/mshayanh13/Weather
// api fields as per: https://openweathermap.org/api/one-call-api#list1


import Foundation

struct Result: Codable {
    let lat: Double // Geographical coordinates of the location (latitude)
    let lon: Double //  Geographical coordinates of the location (longitude)
    let timezone: String // Timezone name for the requested location
    let current: Current // Data point requested,
    var hourly: [Hourly] //  Data block contains hourly historical data starting at 00:00 on the requested day and continues until 23:59 on the same day (UTC time)
    var daily: [Daily] // Data block contains daily historical data starting at 00:00 on the requested day and continues until 23:59 on the same day (UTC time)
    
    mutating func sortHourlyArray() { // sort data in hourly array
        hourly.sort { (hour1: Hourly, hour2: Hourly) -> Bool in // passed two hour objects, sorted using sort function
            return hour1.dt < hour2.dt
        }
    }
    
    mutating func sortDailyArray() { // sort data in daily array
        daily.sort { (day1, day2) -> Bool in // passed two day objects, sorted using sort function
            return day1.dt < day2.dt
        }
    }
}

struct Current: Codable {
    let dt: Int // Data point dt refers to the requested time, rather than the current time
    let sunrise: Int // Sunrise time, Unix, UTC
    let sunset: Int // Sunset time, Unix, UTC
    let temp: Double // Temperature. Units in fahrenheit
    let feels_like: Double // Temperature. This accounts for the human perception of weathe
    let pressure: Int // Atmospheric pressure on the sea level, hPa
    let humidity: Int // Humidity, %
    let dew_point: Double // Atmospheric temperature (varying according to pressure and humidity) below which water droplets begin to condense and dew can form.
    let uvi: Double // Midday UV index
    let clouds: Int //  Cloudiness, %
    let wind_speed: Double // Wind speed. Wind speed. Units – default: metre/sec, metric: metre/sec, imperial: miles/hour
    let wind_deg: Int // Wind direction, degrees (meteorological)
    let weather: [Weather] // weather condition array
}

struct Weather: Codable {
    let id: Int // Weather condition id per https://openweathermap.org/weather-conditions#Weather-Condition-Codes-2
    let main: String // Group of weather parameters (Rain, Snow, Extreme etc.)
    let description: String // Weather condition within the group
    let icon: String // Weather icon id as per https://openweathermap.org/weather-conditions
}

struct Hourly: Codable { // codes same as above
    let dt: Int
    let temp: Double
    let feels_like: Double
    let pressure: Int
    let humidity: Int
    let dew_point: Double
    let clouds: Int
    let wind_speed: Double
    let wind_deg: Int
    let weather: [Weather]
}

struct Daily: Codable { // codes same as above
    let dt: Int
    let sunrise: Int
    let sunset: Int
    let temp: Temperature
    let feels_like: Feels_Like
    let pressure: Int
    let humidity: Int
    let dew_point: Double
    let wind_speed: Double
    let wind_deg: Int
    let weather: [Weather]
    let clouds: Int
    let uvi: Double
}

struct Temperature: Codable {
    let day: Double // day time temperature
    let min: Double // min temperature
    let max: Double // max temperature
    let night: Double // night tempeature
    let eve: Double // evening temperature
    let morn: Double // morning temperature
}

struct Feels_Like: Codable {
    let day: Double // day time feels like temp, accounts for wind, pressure, uvi etc
    let night: Double // night time feels like temp
    let eve: Double // evening time feels like temp
    let morn: Double // morning time feels like temp
}
