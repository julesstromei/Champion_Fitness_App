//
//  Events.swift
//  STROMEI_ASSIGNMENT
//
//  Created by Julian Stromei on 6/11/21.
//

import Foundation

// file for storing incoming events retrieved from firebase for display in the calendarViewController class

class Events {
    
    var eventName: String?
    var eventDescription: String?
    var eventDate: String?
    var locationName: String?
    
    
    init(name: String?, date: String?, description: String?) { // initialise data for event without lcoation
        self.eventName = name
        self.eventDescription = date
        self.eventDate = description
    }
    
    init(name: String?, date: String?, description: String?, locationName: String?) { // initialise event with associated location details
        self.eventName = name
        self.eventDescription = date
        self.eventDate = description
        self.locationName = locationName
    }
    
    
}
