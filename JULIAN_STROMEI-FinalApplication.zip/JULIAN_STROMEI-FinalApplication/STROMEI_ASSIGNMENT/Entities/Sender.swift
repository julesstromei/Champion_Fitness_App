//
//  Sender.swift
//  FIT3178-W08-LabAlternateSolution
//
//  Created by Joshua Olsen on 24/4/21.
//

import UIKit
import MessageKit

// constructs user which acts as a sender of a message in messageKit
class Sender: SenderType {
    var photoURL : String 
    var senderId: String
    var displayName: String
    
    init(id: String, name: String) {
        self.senderId = id
        self.displayName = name
        self.photoURL = ""
    }
    
    init(id: String, name: String, photoUrl: String) { // for intialising a user with their profile photos
        self.senderId = id
        self.displayName = name
        self.photoURL = photoUrl
    }
}

