//
//  Channel.swift
//  FIT3178-W08-LabAlternateSolution
//
//  Created by Joshua Olsen on 24/4/21.
//

import UIKit
// specifies the group channel for messages to be sent to 
class Channel: NSObject {
    let id: String
    let name: String
    
    init(id: String, name: String) {
        self.id = id
        self.name = name
    }
}
