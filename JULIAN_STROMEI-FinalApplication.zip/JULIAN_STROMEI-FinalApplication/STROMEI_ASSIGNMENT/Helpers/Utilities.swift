//
//  Utilities.swift
//  customauth
//
//  Created by Christopher Ching on 2019-05-09.
//  Copyright © 2019 Christopher Ching. All rights reserved.
//  Adapted for use by Julian Stromei

//Sourced from: https://codewithchris.com/source-code/#firebaseauth

import Foundation
import UIKit

//MARK: UI object stylings
public class Utilities: NSObject {
    
    // set stylings for textfields
    static func styleTextField(_ textfield:UITextField) {
        
        // Create the bottom line
        let bottomLine = CALayer()
        // set line color to be from the UI color set in the Assets folder
        let myColor : UIColor = UIColor(named: "SolidButtonBackground")!
        
        //set the dimensions of the bottom line
        bottomLine.frame = CGRect(x: 0, y: textfield.frame.height - 5 , width: textfield.frame.width - 10, height: 2)
        
        // apply the line color to the object
        bottomLine.backgroundColor = myColor.cgColor
        
        // Remove border on text field
        textfield.borderStyle = .none
        
        // Add the line to the text field
        textfield.layer.addSublayer(bottomLine)
        // Set the color of the text field text
        textfield.tintColor =  UIColor(named: "TextFieldText")
        
    }
    //set sylings for a solid button
    static func styleFilledButton(_ button:UIButton) {
        //choose and apply border color
        let myColor : UIColor = UIColor(named: "SolidButtonBorder")!
        button.layer.borderColor = myColor.cgColor
        
        button.backgroundColor =  UIColor(named: "SolidButtonBackground")
        // Filled rounded corner style
        button.layer.cornerRadius = 25.0
        button.layer.borderWidth = 2
        // set text color
        button.tintColor = UIColor(named: "SolidButtonText")
    }
    
    // set stylings for a hollow button
    static func styleHollowButton(_ button:UIButton) {
        // choose border colour
        let myColor : UIColor = UIColor(named: "HollowButtonBorder")!
        // apply the color to the border
        button.layer.borderColor = myColor.cgColor
        
        button.layer.borderWidth = 2
        button.backgroundColor =  UIColor(named: "HollowButtonBackground")
        // Hollow rounded corner style
        button.layer.cornerRadius = 25.0
        // set the text color
        button.tintColor =  UIColor(named: "HollowButtonText")
    }
    
    // password validation function
    static func isPasswordValid(_ password : String) -> Bool {
        // set the passord rule require 8 letters, and one special character
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", "^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,}")
        return passwordTest.evaluate(with: password)
    }
    
}
