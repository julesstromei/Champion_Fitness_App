//
//  Constants.swift
//  CustomLoginDemo
//
//  Created by Christopher Ching on 2019-07-23.
//  Copyright © 2019 Christopher Ching. All rights reserved.
//
//Sourced from: https://codewithchris.com/source-code/#firebaseauth
 
import Foundation

struct Constants {
    
    struct Storyboard {
        //static variables corresponding to storyboardIDs
        static let homeViewController = "homeViewController"
        static let authViewController = "authViewController"
        
    }
    
    
}
