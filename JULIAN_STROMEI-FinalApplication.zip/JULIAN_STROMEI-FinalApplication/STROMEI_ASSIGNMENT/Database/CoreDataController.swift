//
//  CoreDataController.swift
//  W03 - Lab
//
//  Created by Michael Wybrow on 4/4/20.
//  Copyright © 2020 Monash University. All rights reserved.
//

import UIKit
import CoreData

class CoreDataController: NSObject, NSFetchedResultsControllerDelegate, DatabaseProtocol {
    
    //set persistant storage container
    var listeners = MulticastDelegate<DatabaseListener>()
    var persistentContainer: NSPersistentContainer
    
    // Fetched Results Controllers
    var allEventsFetchedResultsController: NSFetchedResultsController<Event>?
    var allLocationsFetchedResultsController: NSFetchedResultsController<Location>?
    
    
    // MARK: - Initialisation
    override init() {
        // Load the Core Data Stack
        persistentContainer = NSPersistentContainer(name: "ChampionCoreDataModel")
        persistentContainer.loadPersistentStores() { (description, error) in
            if let error = error {
                fatalError("Failed to load Core Data stack: \(error)")
            }
        }
        
        super.init()
    }
    
    
    
    
    func saveContext() {
        if persistentContainer.viewContext.hasChanges {
            do {
                try persistentContainer.viewContext.save()
            } catch {
                fatalError("Failed to save to CoreData: \(error)")
            }
        }
    }
    
    // MARK: - Database Protocol Functions
    func cleanup() {
        saveContext()
    }
    
    
    // MARK: - Events
    
    
    func addEvent(name: String, description: String, date: String) -> Event {
        let event = NSEntityDescription.insertNewObject(forEntityName: "Event",
                                                        into: persistentContainer.viewContext) as! Event
        event.eventName = name
        event.eventDescription = description
        event.eventDate = date
        
        return event
    }
    
    
    func deleteEvent(event: Event) {
        persistentContainer.viewContext.delete(event)
    }
    
    // MARK: - Location
    
    func addLocation(name: String, longitude: String, latitude: String) -> Location {
        let location = NSEntityDescription.insertNewObject(forEntityName: "Location",
                                                           into: persistentContainer.viewContext) as! Location
        location.locationLatitude = latitude
        location.locationLongitude = longitude
        location.locationName = name
        
        return location
    }
    
    func addLocationToEvent(location: Location, event: Event) -> Bool {
        event.eventLocation = location
        return true
    }
    
    func removeLocationFromEvent(location: Location, event: Event) {
        event.eventLocation = nil
    }
    
    func deleteLocation(location : Location){
        persistentContainer.viewContext.delete(location)
    }
    
    
    // MARK: - Listeners
    
    func addListener(listener: DatabaseListener) {
        listeners.addDelegate(listener)
    }
    
    func removeListener(listener: DatabaseListener) {
        listeners.removeDelegate(listener)
    }
    
    // MARK: - Fetched Results Controller Protocol Functions
    //    func controllerDidChangeContent(_ controller:
    //
    //        NSFetchedResultsController<NSFetchRequestResult>) {
    //
    //        if controller == allHeroesFetchedResultsController {
    //            listeners.invoke { (listener) in
    //                if listener.listenerType == .heroes || listener.listenerType == .all {
    //                    listener.onHeroListChange(change: .update, heroes: fetchAllHeroes())
    //                }
    //            }
    //        } else if controller == teamHeroesFetchedResultsController {
    //            listeners.invoke { (listener) in
    //                if listener.listenerType == .team || listener.listenerType == .all {
    //                    listener.onTeamChange(change: .update, teamHeroes: fetchTeamHeroes())
    //                }
    //            }
    //        }
    //    }
    
    // MARK: - Core Data Fetch Requests
    func fetchAllEvents() -> [Event] {
        // If results controller not currently initialized
        if allEventsFetchedResultsController == nil {
            let fetchRequest: NSFetchRequest<Event> = Event.fetchRequest()
            // Sort by name
            let nameSortDescriptor = NSSortDescriptor(key: "eventName", ascending: true)
            fetchRequest.sortDescriptors = [nameSortDescriptor]
            // Initialize Results Controller
            allEventsFetchedResultsController =
                NSFetchedResultsController<Event>(fetchRequest:
                                                    fetchRequest, managedObjectContext: persistentContainer.viewContext,
                                                  sectionNameKeyPath: nil, cacheName: nil)
            // Set this class to be the results delegate
            allEventsFetchedResultsController?.delegate = self
            
            do {
                try allEventsFetchedResultsController?.performFetch()
            } catch {
                print("Fetch Request Failed: \(error)")
            }
        }
        
        var events = [Event]()
        if allEventsFetchedResultsController?.fetchedObjects != nil {
            events = (allEventsFetchedResultsController?.fetchedObjects)!
        }
        
        return events
    }
    
    
    // MARK: - Default Entry Generation
    func createDefaultEntries() {
        let _ = addEvent(name: "My Birthday", description: "Its My Birthday", date: "07-Jan-2021")
        let _ = addEvent(name: "My Birthday", description: "Its My Birthday", date: "08-Jul-2021")
        let _ = addEvent(name: "My Birthday", description: "Its My Birthday", date: "07-Jun-2021")
        let _ = addEvent(name: "My Birthday", description: "Its My Birthday", date: "07-Jul-2021")
        let _ = addEvent(name: "My Birthday", description: "Its My Birthday", date: "21-Jun-2021")
    }
}
