//

//
//  Created by Julian Stromei on 4/4/20.
//  Copyright © 2020 Monash University. All rights reserved.
//

import Foundation

//set types of database changes
enum DatabaseChange {
    case add
    case remove
    case update
}

//set listener types
enum ListenerType {
    case event
    case location
    case all
}

// add database listeners
protocol DatabaseListener: AnyObject {
    var listenerType: ListenerType {get set}
    func onLocationChange(change: DatabaseChange, eventLocation: Location)
}

// set methods for coreData controller
protocol DatabaseProtocol: AnyObject {
    
    func cleanup()
    func addEvent(name: String, description: String, date: String) -> Event
    func addLocation(name: String, longitude: String, latitude: String) -> Location
    func addLocationToEvent(location: Location, event: Event) -> Bool
    func deleteEvent(event: Event)
    func removeLocationFromEvent(location: Location, event: Event)
    func deleteLocation(location: Location)
    func addListener(listener: DatabaseListener)
    func removeListener(listener: DatabaseListener)
}
