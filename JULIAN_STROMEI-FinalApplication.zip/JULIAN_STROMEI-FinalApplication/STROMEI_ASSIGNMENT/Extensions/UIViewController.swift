//
//  UIViewController.swift
//  STROMEI_ASSIGNMENT
//
//  Created by Julian Stromei on 4/5/21.
//

import UIKit

extension UIViewController {
    
    
    // Displays UI Alert controller Displays Title and Message, Can only be dismissed as default
    func displayMessage(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
}
