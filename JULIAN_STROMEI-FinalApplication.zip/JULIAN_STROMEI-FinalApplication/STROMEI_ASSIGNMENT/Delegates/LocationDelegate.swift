//
//  LocationDelegate.swift
//  STROMEI_ASSIGNMENT
//
//  Created by user185645 on 6/5/21.

import Foundation
// delegate for passing Location information to the event for creation
protocol AddLocationDelegate: AnyObject {
    func addLocation(locationName: String, locationLat: String, locationLong: String)
}
