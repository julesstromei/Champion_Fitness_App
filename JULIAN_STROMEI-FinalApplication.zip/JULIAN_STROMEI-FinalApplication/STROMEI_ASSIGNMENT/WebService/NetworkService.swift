//
//  NetworkService.swift
//  Weather
//
//  Created by Mohammad Shayan on 4/16/20.
//  Copyright © 2020 Mohammad Shayan. All rights reserved.
//
// sourced from: https://github.com/mshayanh13/Weather
import Foundation


class NetworkService {
    static let shared = NetworkService()
    
    //MARK: WEB API BUILD
    let URL_SAMPLE = "https://api.openweathermap.org/data/2.5/onecall?lat=60.99&lon=30.9&appid=bc58848583ef58b95ac84f6729e6c539" // sample api url
    let URL_API_KEY = "bc58848583ef58b95ac84f6729e6c539" // api key needed to fetch api data
    var URL_LATITUDE = "60.99" // // example details to configure map
    var URL_LONGITUDE = "30.0"
    var URL_GET_ONE_CALL = "" // specifies web api query to be made from those available at openweathermap.org
    let URL_BASE = "https://api.openweathermap.org/data/2.5" // url base
    
    let session = URLSession(configuration: .default) // start session
    
    func buildURL() -> String { // build the url to search
        URL_GET_ONE_CALL = "/onecall?lat=" + URL_LATITUDE + "&lon=" + URL_LONGITUDE + "&units=imperial" + "&appid=" + URL_API_KEY
        return URL_BASE + URL_GET_ONE_CALL
    }
    
    //MARK: SETTERS and GETTERS
    func setLatitude(_ latitude: String) { // get the latitude specified to add to the url
        URL_LATITUDE = latitude
    }
    
    func setLatitude(_ latitude: Double) { // get the latitude specified to add to the url from another latitude
        setLatitude(String(latitude))
    }
    
    func setLongitude(_ longitude: String) { // get the longitude specified to add to the url
        URL_LONGITUDE = longitude
    }
    
    func setLongitude(_ longitude: Double) { // get the longitude specified to add to the url from another longitude
        setLongitude(String(longitude))
    }
    
    func getWeather(onSuccess: @escaping (Result) -> Void, onError: @escaping (String) -> Void) { // get the weather forecaster details
        guard let url = URL(string: buildURL()) else { // build the url
            onError("Error building URL")
            return
        }
        
        let task = session.dataTask(with: url) { (data, response, error) in // query the web api and store the session data
            // sessions are used so api does not have to be authenicated constantly
            
            DispatchQueue.main.async { // complete all these tasks at one by one and do not return until all are completed
                if let error = error {
                    onError(error.localizedDescription) // check for errors
                    return
                }
                
                guard let data = data, let response = response as? HTTPURLResponse else { // check for invalid data for location entered
                    onError("Invalid data or response")
                    return
                }
                
                do {
                    if response.statusCode == 200 { // if reeponse code is 200 data has been retrieved successfully else
                        let items = try JSONDecoder().decode(Result.self, from: data)
                        onSuccess(items)
                    } else { // print the error message code to determine for testing reasons why api data can not be retrived
                        onError("Response wasn't 200. It was: " + "\n\(response.statusCode)")
                    }
                } catch { // print error
                    onError(error.localizedDescription)
                }
            }
            
        }
        task.resume() // resume all other tasks 
    }
    
}
