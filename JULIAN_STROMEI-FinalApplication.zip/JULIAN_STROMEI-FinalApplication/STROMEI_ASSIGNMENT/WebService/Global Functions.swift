//
//  Global Functions.swift
//  Weather
//
//  Created by Mohammad Shayan on 4/16/20.
//  Copyright © 2020 Mohammad Shayan. All rights reserved.
//
// sourced from: https://github.com/mshayanh13/Weather

import UIKit
// MARK: Date Functions

extension Date {

    // get todays date as a string
    static func getTodaysDate() -> String {
        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.timeStyle = .none // no min/hour in date string
        dateFormatter.dateStyle = .full // full date format i.e dd//mm//yyyy
        return dateFormatter.string(from: date) // return date as string
    }
     // get hour from date return as string
    static func getHourFrom(date: Date) -> String {
        
        let dateFormatter = DateFormatter()
        
        dateFormatter.timeStyle = .short //hour.min
        dateFormatter.dateStyle = .none // do day/mon/year
        var string = dateFormatter.string(from: date)
        if string.last == "M" { // if the last character in the string is a minute
            string = String(string.prefix(string.count - 3)) // list as minutes not hours
        }
        return string
    }
     
    // get day of the week as string
    static func getDayOfWeekFrom(date: Date) -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.timeStyle = .none // no hours min
        dateFormatter.dateStyle = .long
        var string = dateFormatter.string(from: date) // wednesday, 15 Jun 2021
        if let index = string.firstIndex(of: ",") { // find the first index ,
            string = String(string.prefix(upTo: index)) // return string before commar
            return string
        }
        return "error"
    }
}
