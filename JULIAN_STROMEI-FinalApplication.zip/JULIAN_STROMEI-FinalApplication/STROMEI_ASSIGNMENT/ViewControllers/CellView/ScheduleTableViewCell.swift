//
//  ScheduleTableViewCell.swift
//  STROMEI_ASSIGNMENT
//
//  Created by user185645 on 6/6/21.
//

import UIKit

class ScheduleTableViewCell: UITableViewCell {
// used for calendar table view
    
    @IBOutlet weak var locationMarker: UIImageView! // imaage view to show if event has location
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
