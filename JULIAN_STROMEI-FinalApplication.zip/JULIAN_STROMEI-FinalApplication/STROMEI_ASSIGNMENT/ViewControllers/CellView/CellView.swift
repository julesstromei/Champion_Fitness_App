//
//  CellView.swift
//  testApplicationCalendar
//
//  Created by JayT on 2016-03-04.
//  Copyright © 2016 OS-Tech. All rights reserved.
//

import UIKit
import JTAppleCalendar

class CellView: JTACDayCell {
    // on the calendar the dot represent an event on a given day
    @IBOutlet var dotView: UIView!
    // the day label represents the number on a calendar day
    @IBOutlet var dayLabel: UILabel!
}
