//
//  WeatherDetailView.swift
//  Weather
//
//  Created by Mohammad Shayan on 4/16/20.
//  Copyright © 2020 Mohammad Shayan. All rights reserved.
// sourced from: https://github.com/mshayanh13/Weather

import UIKit

class WeatherDetailView: FancyView {

    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet weak var topLabel1: UILabel! // lables on top of icon in hourly or daliy view numbered left to right
    @IBOutlet weak var topLabel2: UILabel!
    @IBOutlet weak var topLabel3: UILabel!
    @IBOutlet weak var topLabel4: UILabel!
    @IBOutlet weak var topLabel5: UILabel!
    
    @IBOutlet weak var imageView1: UIImageView! // icons in hourl or daily view numbered left to right
    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var imageView3: UIImageView!
    @IBOutlet weak var imageView4: UIImageView!
    @IBOutlet weak var imageView5: UIImageView!
    
    @IBOutlet weak var bottomLabel1: UILabel! // labels underneath icons in hourly or daily view numbered left to right
    @IBOutlet weak var bottomLabel2: UILabel!
    @IBOutlet weak var bottomLabel3: UILabel!
    @IBOutlet weak var bottomLabel4: UILabel!
    @IBOutlet weak var bottomLabel5: UILabel!
    
    func clear() { // clear al labels
        let labels = [topLabel1, topLabel2, topLabel3, topLabel4, topLabel5, bottomLabel1, bottomLabel2, bottomLabel3, bottomLabel4, bottomLabel5], images = [imageView1, imageView2, imageView3, imageView4, imageView5]
        for label in labels {
            label?.text = ""
        }
        for image in images { // clear all images
            image?.image = nil
        }
    }
    
    func updateViewForToday(_ hourly: [Hourly]) {
        updateHours(hourly: hourly) // update hourly data
    }
    
    func updateViewForWeekly(_ daily: [Daily]) {
        updateDays(daily: daily) // upadte weekly data
    }
    
    func getSelectedTitle() -> String { // return the title of the segmented index selection, i.e hourly or daily
        let index = segmentedControl.selectedSegmentIndex
        let title = segmentedControl.titleForSegment(at: index) ?? ""
        
        return title // return the users selection
        
    }
    
    func updateHours(hourly: [Hourly]) {
        let topLabels = [topLabel1, topLabel2, topLabel3, topLabel4, topLabel5], bottomLabels = [bottomLabel1, bottomLabel2, bottomLabel3, bottomLabel4, bottomLabel5], images = [imageView1, imageView2, imageView3, imageView4, imageView5]
        for i in 0...4 { // for index 0 to 4 updated the labels and icons for each hour
            
            let hour = hourly[i + 1] // 0 indexed array
            let date = Date(timeIntervalSince1970: Double(hour.dt))// get date as time of request since 1970
            let hourString = Date.getHourFrom(date: date)
            let weatherIconName = hour.weather[0].icon // dislay appropriate icon from icon chart in https://openweathermap.org/weather-conditions
            let weatherTemperature = (hour.temp - 32) * (5/9) // convert temp to celsius and store
            
            topLabels[i]?.text = hourString // set top labels to be the upcoming hours in the day
            images[i]?.image = UIImage(named: weatherIconName) // display the appropriate image from assets as listed in the icon json
            bottomLabels[i]?.text = "\(Int(weatherTemperature.rounded()))°C" // display rounded temp as Celsius
        }
        
    }
    
    func updateDays(daily: [Daily]) {
        let topLabels = [topLabel1, topLabel2, topLabel3, topLabel4, topLabel5], bottomLabels = [bottomLabel1, bottomLabel2, bottomLabel3, bottomLabel4, bottomLabel5], images = [imageView1, imageView2, imageView3, imageView4, imageView5]
        for i in 0...4 { // for index 0 to 4 updated the labels and icons for each day
            
            let day = daily[i + 2] // 0 indexed array
            let date = Date(timeIntervalSince1970: Double(day.dt)) // get date as time of request since 1970
            let dayString = Date.getDayOfWeekFrom(date: date)
            let weatherIconName = day.weather[0].icon // dislay appropriate icon from icon chart in https://openweathermap.org/weather-conditions
            let weatherTemperature = (day.temp.day - 32) * (5/9) // convert temp to celsius and store
            
            topLabels[i]?.text = dayString // set top labels to be the upcoming days in the week
            images[i]?.image = UIImage(named: weatherIconName) // display the appropriate image from assets as listed in the icon json
            bottomLabels[i]?.text = "\(Int(weatherTemperature.rounded()))°C" // display rounded temp as Celsius
        
        }
    }
}
