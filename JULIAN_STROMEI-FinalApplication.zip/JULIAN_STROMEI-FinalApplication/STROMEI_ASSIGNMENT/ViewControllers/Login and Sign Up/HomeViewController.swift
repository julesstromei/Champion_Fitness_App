//
//  HomeViewController.swift
//  Assignment3
//
//  Created by Julian Stromei on 22/4/21.
//
// used  https://www.youtube.com/watch?v=1HN7usMROt8&t=36
import UIKit
import FirebaseAuth

class HomeViewController: UIViewController {
    
    // set button outlets
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var logInButton: UIButton!
    
    // handler to listener for changes in user authentication
    var handle: AuthStateDidChangeListenerHandle?
    
    // MARK: - Auth - View Will Appear/ Disappear
    
    //if the view appears add the listener
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //  add listener
        handle = Auth.auth().addStateDidChangeListener( { (auth, user) in
            if (user != nil) { // if a user has been logged in but not logged out
                
                // load the screen with storyboard ID homeViewcontroller, with the HomeTabBarController loaded
                let homeViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.homeViewController) as? HomeTabBarController
                
                // make it the root view controler and make it visible
                self.view.window?.rootViewController = homeViewController
                self.view.window?.makeKeyAndVisible()
            }
        })
    }
    
    //if the view disappears remove the listener
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        Auth.auth().removeStateDidChangeListener(handle!)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpElements() // set up UI object stylings
    }
    
    func setUpElements() {
        
        // set stylings for UI objects from utilities.swifts
        
        Utilities.styleFilledButton(signUpButton)
        Utilities.styleHollowButton(logInButton)
        
    }
    
    
}
