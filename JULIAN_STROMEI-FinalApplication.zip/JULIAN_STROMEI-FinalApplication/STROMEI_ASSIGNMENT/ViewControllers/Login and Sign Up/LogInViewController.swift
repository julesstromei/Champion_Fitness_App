//
//  LogInViewController.swift
//  Assignment3
//
//  Created by Julian Stromei on 22/4/21.
//
// used  https://www.youtube.com/watch?v=1HN7usMROt8&t=36
import UIKit
import FirebaseAuth


class LogInViewController: UIViewController {
    
    // MARK: - Local Variable initialisation
    // outlets for UI Objects
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var logInButton: UIButton!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    
    // handler to listener for changes in user authentication
    var handle: AuthStateDidChangeListenerHandle?
    
    
    // MARK: - Auth - View Will Appear/ Disappear
    
    //if the view appears add the listener
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //  add listener
        handle = Auth.auth().addStateDidChangeListener( { (auth, user) in
            if (user != nil) { // if a user has been logged in but not logged out
                
                // transition to the home tab bar controller and view
                self.transitionHome()
            }
        })
    }
    
    //if the view disappears remove the listener
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        Auth.auth().removeStateDidChangeListener(handle!)
    }
    
    // MARK: - View Did Load
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // add stylings for the UI objects
        setUpElements()
        
        // set textfield delegates so that the return button can be pressed to remove the ui keyboard
        emailTextField.delegate = self // set delegate
        passwordTextField.delegate = self // set delegate
        
        
        // Do any additional setup after loading the view.
    }
    
    func setUpElements() {
        
        //Hide the error label
        errorLabel.alpha = 0
        
        // set stylings for the following objects from Utilities.swift
        Utilities.styleTextField(emailTextField)
        Utilities.styleTextField((passwordTextField))
        Utilities.styleFilledButton(logInButton)
    }
    
    // MARK: - Handle logIn
    @IBAction func logIN(_ sender: Any) {
        // TODO: Validate Text Fields
        
        // Create cleaned versions of the text field
        let email = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Signing in the user
        Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
            
            if error != nil {
                // Couldn't sign in
                //display message with localisation
                self.displayMessage(title: "Error occurred Signing In", message: error!.localizedDescription)
                
                // set error label message for testing purposes
                self.errorLabel.text = error?.localizedDescription
                
                
            }
            else { // sign in was succesfull
                
                // transition to the home tab bar controller and view
                self.transitionHome()
            }
        }
    }
    
    //MARK:  - Transition to Home
    func transitionHome(){
        // load the screen with storyboard ID homeViewcontroller, with the HomeTabBarController loaded
        let homeViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.homeViewController) as? HomeTabBarController
        
        // make it the root view controler and make it visible
        self.view.window?.rootViewController = homeViewController
        self.view.window?.makeKeyAndVisible()
    }
    
}

// enables keyboard to be dismissed for textfields that follow this delegation.
extension LogInViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder() // dismiss keyboard
        return true
    }
}



