//
//  SignUpViewController.swift
//  Assignment3
//
//  Created by Julian Stromei on 22/4/21.
//
// used  https://www.youtube.com/watch?v=1HN7usMROt8&t=36
import UIKit
import FirebaseAuth
import Firebase
import FirebaseFirestore



class SignUpViewController:
    UIViewController {
    
    
    // MARK: - Local Variable initialisation
    // outlets for UI Objects
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var errorLabel: UILabel!
    
    let dataBase = Firestore.firestore() // connection to firebase data storage
    var handle: AuthStateDidChangeListenerHandle? // handler to listener for changes in user authentication
    
    // MARK: - Auth - View Will Appear/ Disappear
    
    //if the view appears add the listener
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //  add listener
        handle = Auth.auth().addStateDidChangeListener( { (auth, user) in
            if (user != nil) { // if a user has been logged in but not logged out
                
                // transition to the home tab bar controller and view
                self.transitionHome()
            }
        })
    }
    
    //if the view disappears remove the listener
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        Auth.auth().removeStateDidChangeListener(handle!)
    }
    
    // MARK: - View Did Load
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // add stylings for the UI objects
        setUpElements()
        
    }
    
    func setUpElements() {
        
        //Hide the error label
        errorLabel.alpha = 1
        
        // set textfield delegates so that the return button can be pressed to remove the ui keyboard
        emailTextField.delegate = self // set delegate
        passwordTextField.delegate = self // set delegate
        firstNameTextField.delegate = self // set delegate
        lastNameTextField.delegate = self // set delegate
        
        Utilities.styleTextField(firstNameTextField)
        Utilities.styleTextField((lastNameTextField))
        Utilities.styleTextField(emailTextField)
        Utilities.styleTextField((passwordTextField))
        Utilities.styleFilledButton(signUpButton)
    }
    
    @IBAction func signUp(_ sender: Any) {
        // Validate the fields
        let error = validateFields()
        
        if error != nil {
            
            // There's something wrong with the fields, show error message
            showError(error!)
            return
        }
        else {
            
            // Create cleaned versions of the data
            let firstName = firstNameTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let lastName = lastNameTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let email = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let password = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
         
            // Create the user
            Auth.auth().createUser(withEmail: email, password: password) { (result, error) in
                
                
                // Check for errors
                if error != nil {
                    
                    // There was an error creating the user
                    self.showError("Error creating user")
                    self.displayMessage(title: "Error creating profile", message: error!.localizedDescription)
                    return
                }
                else {
                    
                    // User was created successfully,
                    let userID = Auth.auth().currentUser!.uid
                    print(userID)
                    // now store the first name and last name in a personal firebase document
                    self.dataBase.collection("users").document("\(userID)").setData(["firstName":firstName, "lastName":lastName], merge:true){ (error) in
                        
                        if error != nil {
                            // Show error message
                            self.showError("Error saving user data")
                        }
                        else {
                            // Transition to the home screen
                            self.transitionHome()
                        }
                    }
                    
                    
                    
                }
                
            }
            
        }
    }
    
    
    
    
    // validates sign up fields, if correct it returns nil otherwise error message will be displayed.
    func validateFields() -> String? {
        
        // Check that all fields are filled in
        if firstNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            lastNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            
            return "Please fill in all fields."
        }
        
        
        let cleanedPassword = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Check if the password is secure from function in utilities .swift
        if Utilities.isPasswordValid(cleanedPassword) == false {
            // Password isn't secure enough display message
            displayMessage(title: "Password Not Secure", message: "Please make sure your password is at least 8 characters, contains a special character and a number.")
            return "Password not secure"
        }
        
        return nil
    }
    
    // make error label visible and set its text to the input
    func showError(_ message:String) {
        
        errorLabel.text = message
        errorLabel.alpha = 1
    }
    
    
    //MARK:  - Transition to Home
    func transitionHome(){
        // load the screen with storyboard ID homeViewcontroller, with the HomeTabBarController loaded
        let homeViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.homeViewController) as? HomeTabBarController
        
        // make it the root view controler and make it visible
        self.view.window?.rootViewController = homeViewController
        self.view.window?.makeKeyAndVisible()
    }
    
}

extension SignUpViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder() // dismiss keyboard
        return true
    }
}
