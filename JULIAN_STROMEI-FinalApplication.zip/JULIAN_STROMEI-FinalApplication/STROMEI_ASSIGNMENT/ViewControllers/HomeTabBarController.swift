//
//  HomeTabBarController.swift
//  STROMEI_ASSIGNMENT
//
//  Created by Julian Stromei on 6/5/21.
//

import UIKit

class HomeTabBarController: UITabBarController {
// is here just to facilitate other view controllers 
    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
