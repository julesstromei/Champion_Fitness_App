//
//  ChannelsTableViewController.swift
//  FIT3178-W08-LabAlternateSolution
//
//  Created by Joshua Olsen on 24/4/21.
// adapted by Julian Stromei

import UIKit
import FirebaseFirestore
import FirebaseAuth
import Firebase

class ChannelsTableViewController: UITableViewController, UISearchResultsUpdating {
    
    
    //MARK: Local Variables
    let SECTION_CHANNEL = 0; // set section identifiers for table view
    let SECTION_INFO = 1;
    
    let CELL_CHANNEL = "channelCell" // set table view cell identifiers
    let CELL_INFO = "infoCell"
    
    //set up reference to firebase collection
    let usersReference = Firestore.firestore().collection("users")
    
    var channels: [Channel] = [] // list of all channels
    var filteredChannels: [Channel] = [] // list of channels to be filtered by search result
    var channelsRef: CollectionReference? // reference to channels collection in firebase
    var databaseListener: ListenerRegistration?
    
    let dataBase = Firestore.firestore() // declare reference to firebase firestore
    
    
    
    // MARK: - ViewController Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let database = Firestore.firestore()
        channelsRef = database.collection("channels") // set reference to channels firestore collection
        
        let searchController = UISearchController(searchResultsController: nil) // set up search ab
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search Groups" // set placeholder text
        navigationItem.searchController = searchController
        
        // This view controller decides how the search controller is presented
        definesPresentationContext = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // on apper of view, get all channels
        databaseListener = channelsRef?.addSnapshotListener() { (querySnapshot, error) in
            
            if let error = error {
                print(error) // check  for errors
                return
            }
            
            self.channels.removeAll() // clear the channels arrary
            
            querySnapshot?.documents.forEach() { snapshot in // for each channel found
                let id = snapshot.documentID // store its data
                let name = snapshot["name"] as! String
                let channel = Channel(id: id, name: name) // create an instance of a channel
                
                self.channels.append(channel) // append to the channels array
            }
            
            self.filteredChannels = self.channels // set the filtered channels list to be the same as all channels
            self.tableView.reloadData() // reload the tables
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        databaseListener?.remove()
    }
    
    //MARK: Search controller
    func updateSearchResults(for searchController: UISearchController) {
        guard let searchText = searchController.searchBar.text?.lowercased() else {
            return // set reference to search text
        }
        
        if searchText.count > 0 { // if the user starts to type in the search bar
            filteredChannels = channels.filter({ (channel: Channel) -> Bool in // filter the list of channels shown
                return channel.name.lowercased().contains(searchText) // show only channels which name matches the search query
            })
        } else {
            filteredChannels = channels // if nothing has been entered, show all channels
        }
        
        tableView.reloadData() // reload the tables
    }
    
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2 // set sections for those specified in local variable section
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case SECTION_CHANNEL: // for the channels section load cells for channels in the filtered channel array
            return filteredChannels.count
        case SECTION_INFO: // display one info cell
            return 1
        default:
            return 0
        }
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == SECTION_INFO { // for the indo cell
            let infoCell = tableView.dequeueReusableCell(withIdentifier: CELL_INFO, for: indexPath)
            
            infoCell.textLabel?.textColor = .secondaryLabel // set its text color
            infoCell.selectionStyle = .none // on user selection of this cell do not show anything
            
            infoCell.textLabel?.text = "Press + to Create a Group"  // set the text of the cell
            infoCell.textLabel?.textAlignment = .center //align text to the centre of the cell
            return infoCell
            
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: CELL_CHANNEL, for: indexPath) // for the other section
        let channel = filteredChannels[indexPath.row] // set a cell for each channel in the filtered channel array
        
        cell.textLabel?.text = channel.name // let the cell dislay channel names for
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == SECTION_INFO { // do not allow selection of info cell
            tableView.deselectRow(at: indexPath, animated: false)
            return
        }
        
        let channel = filteredChannels[indexPath.row] // if a chanel cell is selected
        
        // add group to my groups
        // ensure that a valid user has been logged in
        guard let userID = Auth.auth().currentUser?.uid else {
            returnHome() // return them to the home controller
            return
        }
        
        // under the user's personal file collection in firebase
        let userRef = usersReference.document("\(userID)")
        // save the following channel data in an channel collection folder,
        // save it as a document named after the channel name, merge with an existing document by the same name if it exists
        userRef.collection("channels").document("\(channel.name)").setData(["id": "\(channel.id)"], merge:true){ [self] (error) in
            // if an error occurs present an error message in the local language, here it should be english
            if error != nil {
                self.displayMessage(title: "Error occurred writing to Database", message: error!.localizedDescription)
                
            } // if an error has not occured,
            else {
                // return to lower level view in the stack
                navigationController?.popViewController(animated: true)
                return
            }
        }
    }
    
    
    // MARK: Create  a new Channel
    @IBAction func addChannel(_ sender: Any) {
        //dispay alert message with textbox
        let alertController = UIAlertController(title: "Add New Channel", message: "Enter channel name below", preferredStyle: .alert)
        alertController.addTextField()
        
        // add cancel and create actions to the alert
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let addAction = UIAlertAction(title: "Create", style: .default) { _ in
            let channelName = alertController.textFields![0] // set refernce to text input result
            var doesExist = false // set does the channel exist to false
            
            for channel in self.channels { // look at all the current channel names
                if channel.name.lowercased() == channelName.text!.lowercased() { // if the channel already exists set doesExist to true
                    doesExist = true
                }
            }
            
            if !doesExist { // if the channel does not exist
                self.channelsRef?.addDocument(data: ["name" : channelName.text!]) // add the channel with the name specified
            }
        }
        
        alertController.addAction(cancelAction) // add actions to alet
        alertController.addAction(addAction)
        self.present(alertController, animated: false, completion: nil) // present alert
    }
    
    
    //MARK: navigation
    
    func returnHome() {
        // display error message
        displayMessage(title: "Cannot create event until logged in", message: "You have been inactive for too long, redirecting you to log in")
        //  return them to the landing page for authenitifcation
        let authViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.authViewController) as? HomeViewController
        
        self.view.window?.rootViewController = authViewController
        self.view.window?.makeKeyAndVisible()
    }
    
}
