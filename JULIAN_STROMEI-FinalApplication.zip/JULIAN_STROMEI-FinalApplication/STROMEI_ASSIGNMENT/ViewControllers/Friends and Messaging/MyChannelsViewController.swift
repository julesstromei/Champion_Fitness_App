//
//  ChannelsTableViewController.swift
//  FIT3178-W08-LabAlternateSolution
//
//  Created by Julian Stromei on 14/06/2021

import UIKit
import FirebaseFirestore
import FirebaseAuth
import Firebase

class MyChannelsTableViewController: UITableViewController {
    
    //MARK: Local Variables
    
    let SECTION_CHANNEL = 0; // set section identifiers for table view
    let SECTION_INFO = 1;
    
    let CELL_CHANNEL = "channelCell" // set table view cell identifiers
    let CELL_INFO = "infoCell"
    
    let SEGUE_CHANNEL = "channelSegue" // set segue indentifier 
    
    var currentSender: Sender? // set sender type, loads user details and sends it to ChatmessagesViewController
    var channels = [Channel]() // list of channels
    
    var channelsRef: CollectionReference? // reference to channels collection
    var databaseListener: ListenerRegistration?
    var displayName = "" // set user display name if they do not currently have one
    let usersReference = Firestore.firestore().collection("users")   //set up reference to firebase collection
    
    var eventDetailMessage: String? // takes event details from segue
    
    // MARK: - ViewController Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let database = Firestore.firestore()//set up refence to channels collection
        channelsRef = database.collection("channels")
        
        // set gesture recogniser for right swipe
        
        // sourced from https://stackoverflow.com/questions/44231800/navigate-between-tab-bar-using-swipe-gesture
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
        
        // set gesture recogniser for left swipe
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
        swipeLeft.direction = UISwipeGestureRecognizer.Direction.left
        self.view.addGestureRecognizer(swipeLeft)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // find the current user logged in
        let user = Auth.auth().currentUser
        if let user = user {
            // get their userID
            let userID = user.uid
            
            
            // Read a specific document
            // See: https://firebase.google.com/docs/firestore/query-data/get-data
            usersReference
                .document("\(userID)") // get the user's personal document in the firebase database
                .getDocument { (document, error) in
                    
                    // Check for error
                    if error != nil {
                        self.displayMessage(title: "Error occurred getting your details", message: error!.localizedDescription)
                    }
                    else { // if there are no error's connecting to firebase
                        
                        // Check that this document exists
                        if document != nil && document!.exists {
                            
                            let documentData = document!.data() // if it does take the user's first name
                            
                            let firstName = documentData!["firstName"]  // take users first name
                            
                            let lastName = documentData!["lastName"]  // take the user's last name
                            
                            self.displayName = "\(firstName ?? "") \(lastName ?? "")" // set the users display name to be their full name
                            
                        }
                    }
                    
                }
            self.currentSender = Sender(id: userID, name: self.displayName) // create current sender
            
        }
        loadData() // load list of current users channels
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        databaseListener?.remove()
    }
    
    //MARK: Gestures
    @objc func swiped(_ gesture: UISwipeGestureRecognizer) {
        // on a left swipe for the tab bar controller screen which is one less that this
        if gesture.direction == .left {
            if (self.tabBarController?.selectedIndex)! < 3 { // set your total tabs here
                self.tabBarController?.selectedIndex += 1
            } // on a right swipe for the tab bar controller screen which is one greater that this
        } else if gesture.direction == .right {
            if (self.tabBarController?.selectedIndex)! > 0 {
                self.tabBarController?.selectedIndex -= 1
            }
        }
        
        
    }
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2  // set sections for those specified in local variable section
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { switch section {
    case SECTION_CHANNEL:
        return channels.count // for the channels section load cells for channels in the filtered channel array
    
    case SECTION_INFO:
        return 1 // display one info cell
    default:
        return 0
    }
    
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        if indexPath.section == SECTION_INFO { // for the indo cell
            let infoCell = tableView.dequeueReusableCell(withIdentifier: CELL_INFO, for: indexPath)
            
            infoCell.textLabel?.textColor = .secondaryLabel // set its text color
            infoCell.selectionStyle = .none // on user selection of this cell do not show anything
            
            infoCell.textLabel?.text = "Press + to Add a Group"  // set the text of the cell
            infoCell.textLabel?.textAlignment = .center //align text to the centre of the cell
            return infoCell
            
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: CELL_CHANNEL, for: indexPath)// for channel cell
        let channel = channels[indexPath.row] // create a cell for every one of users current channels
        
        cell.textLabel?.text = channel.name // display the channels name in the textLabel
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == SECTION_INFO { // if the info cell is selected de-select it
            tableView.deselectRow(at: indexPath, animated: false)
            return
        }
        
        let channel = channels[indexPath.row] //else store the channel associated with the cell selected
        performSegue(withIdentifier: SEGUE_CHANNEL, sender: channel) // open up this channels messages
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if indexPath.section == SECTION_CHANNEL { // if the section is for channels allow editing
            return true
        }
        return false
    }
    
    
    //MARK: Delete channel
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete && indexPath.section == SECTION_CHANNEL  { // when deleteing the cell
            let cellDetail = channels[indexPath.row]
            let groupRef = cellDetail.name // get the name of the cell selected
            
            guard let userID = Auth.auth().currentUser?.uid else { // determine if user is still logged in
                returnHome() // return the user to log in
                return
            }
            
            let usersReference = Firestore.firestore().collection("users")
            // under the user's personal file collection in firebase
            let userRef = usersReference.document("\(userID)")
            
            // Delete a document
            // See: https://firebase.google.com/docs/firestore/manage-data/delete-data
            
            userRef.collection("channels") // delete the channel from users channel list
                .document("\(groupRef)")
                .delete { (error) in
                    if error != nil { // Detect for errors, use completion parameter
                        self.displayMessage(title: "Could not remove  Group", message: error!.localizedDescription)
                    }
                    
                }
            loadData() // re load the users channels
        }
        
    }
    
    
    
    
    //MARK: Load Channel Data to display
    func loadData(){
        self.channels.removeAll() // clear the channel array
        guard let userID = Auth.auth().currentUser?.uid else { //if there is no user logged in
            returnHome() // return them to the home controller
            return
        }
        
        // under the user's personal file collection in firebase
        let userRef = usersReference.document("\(userID)")
        // save the following event data in an event collection folder,
        
        // Getting all documents from a collection
        userRef.collection("channels")
            .getDocuments { (snapshot, error) in
                
                if error != nil { // display errors if any
                    self.displayMessage(title: "Error occurred writing to Database", message: error!.localizedDescription)
                }
                if error == nil && snapshot != nil { // if not errors are encountered and there is data retrieved
                    
                    for document in snapshot!.documents { // for all the documents in the collection
                        
                        let documentData = document.data()
                        let channelID = documentData["id"] as! String // store its id
                        
                        self.databaseListener = self.channelsRef!.addSnapshotListener() { (querySnapshot, error) in // find all documents in the channels firebase firestore
                            
                            if let error = error {  //display errors
                                print(error)
                                return
                            }
                            
                            querySnapshot?.documents.forEach() { snapshot in// for each channel in the firestore
                                let id = snapshot.documentID
                                
                                if id == channelID as? String { // if that channel is in the current users list
                                    
                                    let name = snapshot["name"] as! String // create a channel instance
                                    let channel = Channel(id: id, name: name)
                                    
                                    self.channels.append(channel) // append it to the channel array
                                }
                            }
                            
                            self.tableView.reloadData() // reload the table
                        }
                    }
                }
            }
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == SEGUE_CHANNEL { //if the segue is to chatMessagesViewController
            let channel = sender as! Channel
            let destinationVC = segue.destination as! ChatMessagesViewController
            
            // if the controller has been passed an event set the message text to included the event details
            if eventDetailMessage != nil {
                destinationVC.eventDetailMessage = eventDetailMessage
            }
            
            destinationVC.sender = currentSender // send the currentSender infomation to the destination View controller
            destinationVC.currentChannel = channel
        }
    }
    func returnHome() { // display error and return user to re authenticate themselves if they have logged out
        displayMessage(title: "Cannot create event until logged in", message: "You have been inactive for too long, redirecting you to log in")
        // else return them to the landing page for authenitifcation
        let authViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.authViewController) as? HomeViewController
        
        self.view.window?.rootViewController = authViewController
        self.view.window?.makeKeyAndVisible()
    }
    
}
