//
//  ChatMessagesViewController.swift
//  FIT3178-W08-LabAlternateSolution
//
//  Created by Joshua Olsen on 24/4/21.
// adapted by Julian Stromei

import UIKit
import MessageKit
import InputBarAccessoryView
import FirebaseFirestore

class ChatMessagesViewController: MessagesViewController, MessagesDataSource, MessagesLayoutDelegate, MessagesDisplayDelegate, InputBarAccessoryViewDelegate {
    
    //MARK: Local variables
    var sender: Sender? // sender of the messages, is the current user passed by myChannelsViewController
    var currentChannel: Channel? // current channel
    var messagesList = [Message]()// list of   messages to be retieved from firebase
    
    var channelRef: CollectionReference? // reference to firebase collection
    var databaseListener: ListenerRegistration?
    
    var eventDetailMessage: String? // takes event details from segue 
    
    let formatter: DateFormatter = { // format date in current timezone, and in specfied format
        let formatter = DateFormatter()
        formatter.timeZone = .current
        formatter.dateFormat = "HH:mm dd/MM/yy"
        return formatter
    }()
    
    //MARK: View did load
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set data source delegates for messages
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        messageInputBar.delegate = self // register input bar so messages
        
        scrollsToLastItemOnKeyboardBeginsEditing = true // set keyboard preferences
        maintainPositionOnKeyboardFrameChanged = true
        
        if currentChannel != nil {// if there is no specified channel,
            let database = Firestore.firestore()// load the channel passed by the myChannels view controller
            channelRef = database.collection("channels").document(currentChannel!.id).collection("messages")
            
            navigationItem.title = "\(currentChannel!.name)" // set the navigation item to the channel name
        }
    }
    
    //MARK: view did appear, dissapear
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        // get all messages documents from the Channel collection in firebase, order them by tiime of upload
        databaseListener = channelRef?.order(by: "time").addSnapshotListener() { (querySnapshot, error) in
            
            if let error = error {
                print(error) // print errors in establishing firebase connection
                return
            }
            
            querySnapshot?.documentChanges.forEach() { change in
                if change.type == .added { // for any changes in the message list
                    let snapshot = change.document
                    // record the message detais
                    let id = snapshot.documentID
                    let senderId = snapshot["senderId"] as! String
                    let senderName = snapshot["senderName"] as! String
                    let messageText = snapshot["text"] as! String
                    let sentTimestamp = snapshot["time"] as! Timestamp
                    let sentDate = sentTimestamp.dateValue()
                    // create instances of sender and messages
                    let sender = Sender(id: senderId, name: senderName)
                    let message = Message(sender: sender, messageId: id, sentDate: sentDate, message: messageText)
                    self.messagesList.append(message) // add them the message list
                    self.messagesCollectionView.insertSections([self.messagesList.count-1])
                }
            }
        }
        
        // if the controller has been passed an event set the message text to included the event details
        if eventDetailMessage != nil {
            messageInputBar.inputTextView.text = eventDetailMessage
        }
       
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        databaseListener?.remove()
    }
    
    // MARK: - Messages Data Source
    func currentSender() -> SenderType {
        guard let sender = sender else { // if there is no sender specified, let their details be anonymous
            return Sender(id: "",name: "")
        }
        
        return sender // else return the senders information
    }
    
    
   // MARK: Collecction view
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return messagesList[indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return messagesList.count
    }
    
    // for the label on top of a message
    func messageTopLabelAttributedText(for message: MessageType, at indexPath: IndexPath) -> NSAttributedString? {
        let name = message.sender.displayName // display the users name
        return NSAttributedString(string: name, attributes: [NSAttributedString.Key.font:UIFont.preferredFont(forTextStyle: .caption1)])
    }
    
    // for the label underneath the message
    func messageBottomLabelAttributedText(for message: MessageType, at indexPath: IndexPath) -> NSAttributedString? {
        let dateString = formatter.string(from: message.sentDate) // display the date the message was sent in the specified format
        return NSAttributedString(string: dateString, attributes: [NSAttributedString.Key.font:UIFont.preferredFont(forTextStyle: .caption2)])
    }
    

    // MARK: - Message Input Bar Delegate Functions
    
    func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String) {
        if text.isEmpty {
            return // if the message is empty do nothing
        }
        
        channelRef?.addDocument(data: [ // else construct a new message and add it to the firebase collection
            "senderId" : sender!.senderId,
            "senderName" : sender!.displayName,
            "text" : text,
            "time" : Timestamp(date: Date.init())
        ])
        
        inputBar.inputTextView.text = "" // reset the message input
    }
    
    // MARK: - Message Layout Delegate
    // set the height of the cells top label
    func cellTopLabelHeight(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> CGFloat {
        return 18
    }
    // set the height of the cells bottom label
    func cellBottomLabelHeight(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> CGFloat {
        return 17
    }
    // set the height of the messages top label
    func messageTopLabelHeight(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> CGFloat {
        return 20
    }
    // set the height of the cmessages bottom label
    func messageBottomLabelHeight(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> CGFloat {
        return 16
    }
    
    // set style of the message to include icon to show user avatar
    func messageStyle(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageStyle {
        let tail: MessageStyle.TailCorner = isFromCurrentSender(message: message) ? .bottomRight : .bottomLeft
        return .bubbleTail(tail, .curved)
    }
}
