//
//  EditProfileViewController.swift
//  STROMEI_ASSIGNMENT
//
//  Created by user185645 on 6/8/21.
//

import UIKit
import FirebaseAuth
import Firebase

class EditProfileViewController: UIViewController {
    // MARK: - Local Variable initialisation
    
    @IBOutlet weak var firstNameLabel: UILabel! //map UI objects 
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var saveButton: UIButton!
    
    
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var firstNameTextField: UITextField!
    
    let dataBase = Firestore.firestore() // set connection to firestore database
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // get the current user from the firebase listener
        let user = Auth.auth().currentUser
        if let user = user {
            // if there is a user logged in, get their email and userID
            let email = user.email
            emailTextField.text = email // let the email text field hold the users email
            let userID = user.uid
            // there isnt a way to collect the users password without hashing protocols
            
            // Read a specific document
            // See: https://firebase.google.com/docs/firestore/query-data/get-data
            dataBase.collection("users")
                .document("\(userID)") // get the user's personal document in the firebase database
                .getDocument { (document, error) in
                    
                    // Check for error
                    if error != nil {
                        self.displayMessage(title: "Error occurred getting your details", message: error!.localizedDescription)
                    }
                    else { // if there are no error's connecting to firebase
                        
                        // Check that this document exists
                        if document != nil && document!.exists {
                            
                            let documentData = document!.data() // if it does take the user's first name
                            if let firstName = documentData!["firstName"] {
                                self.firstNameTextField.text = (firstName as! String) // and add it to the firstName text field
                            }
                            
                            if let lastName = documentData!["lastName"] { // take the user's last name
                                self.lastNameTextField.text = lastName as! String  // and add it to the lastName text field
                            }
                        }
                        
                    }
                    
                }
            
        }
        // set up UI object stylings
        setUpElements()
    }
    
    // MARK: - Add UI object stylings
    func setUpElements() {
        
        // set textfield delegates so that the return button can be pressed to remove the ui keyboard
        
        emailTextField.delegate = self // set delegate
        passwordTextField.delegate = self // set delegate
        firstNameTextField.delegate = self // set delegate
        lastNameTextField.delegate = self // set delegate
        
        // add stylings for the following objects; see utilities.swift
        Utilities.styleTextField(firstNameTextField)
        Utilities.styleTextField((lastNameTextField))
        Utilities.styleTextField(emailTextField)
        Utilities.styleTextField((passwordTextField))
        Utilities.styleFilledButton(saveButton)
    }
    
    // MARK: - Saving User Details
    @IBAction func saveDetails(_ sender: Any) {
        
        // check if the user is logged in through the auth listener created on login or sign up
        guard let userID = Auth.auth().currentUser?.uid else {
            displayMessage(title: "Cannot create event until logged in", message: "You have been inactive for too long, redirecting you to log in")
            
            
            // navigate back to the storyboard screen with ID authViewController as controlled by the HomeViewController class
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            
            let startViewController = storyBoard.instantiateViewController(withIdentifier: "authViewController") as! HomeViewController
            startViewController.modalPresentationStyle = .fullScreen // display in full screen for swift 5
            self.present(startViewController, animated:true, completion:nil)
            
            
            return
        }
        
        // Validate the fields
        let error = validateFields()
        
        // if an error occurs in validating fields, display it
        if error != nil {
            
            self.displayMessage(title: "Invalid Form Details", message: error!)
        }
        else { // if the form passes validation
            
            //update the users email if it has changed
            Auth.auth().currentUser?.updateEmail(to: emailTextField.text!) { (error) in
                if error != nil { // if an error occurs display it and stop the function
                    self.displayMessage(title: "Error occurred Changing email", message: error!.localizedDescription)
                    return
                }
            }
            //update the users password if it has changed
            Auth.auth().currentUser?.updatePassword(to: passwordTextField.text!) { (error) in
                if error != nil { // if an error occurs display it and stop the function
                    self.displayMessage(title: "Error occurred Changing Password", message: error!.localizedDescription)
                    return
                }
            }
            
            // store the users changes to their display name
            let firstName = "\(firstNameTextField.text!)"
            let lastName = "\(lastNameTextField.text!)"
            
            // in their personal document
            //update the users first and last name
            self.dataBase.collection("users").document("\(userID)").setData(["firstName":firstName, "lastName":lastName], merge:true) { (error) in
                if error != nil { // if an error occurs display it and stop the function
                    self.displayMessage(title: "Error occurred Changing Display Name", message: error!.localizedDescription)
                    return
                }
                
                
            }// else display the change
            displayMessage(title: "Details saved", message: "Values have been updated")
            navigationController?.popViewController(animated: true) // return to lower level view in the stack
        }
        
    }
    
    
    // MARK: - Validation
    func validateFields() -> String? {
        
        // Check that all fields are filled in
        if firstNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            lastNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            // return a string to be displayed in the error message
            return "Please fill in all fields."
        }
        
        // trim the end of the passwor string entered
        let cleanedPassword = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        // Check if the password is secure
        if Utilities.isPasswordValid(cleanedPassword) == false {
            // Password isn't secure enough
            displayMessage(title: "Password Not Secure", message: "Please make sure your password is at least 8 characters, contains a special character and a number.")
            return nil
        }
        
        return nil
    }
    
}

// MARK: - Delegates        
// enables keyboard to be dismissed for textfields that follow this delegation.
extension EditProfileViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder() // dismiss keyboard
        return true
    }
}
