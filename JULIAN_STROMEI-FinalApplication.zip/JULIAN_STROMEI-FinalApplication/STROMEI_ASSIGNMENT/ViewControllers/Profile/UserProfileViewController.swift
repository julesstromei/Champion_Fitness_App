//
//  PhotoViewController.swift
//  Workshop08-0
//
//  Created by Michael Wybrow on 23/4/21.
// adapted by Julian Stromei

import UIKit
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage
import JGProgressHUD

class UserProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    // MARK: - Local Variable initialisation
    //set outlets to buttons for stylings
    @IBOutlet weak var imageButton: UIButton!
    @IBOutlet weak var profileButton: UIButton!
    @IBOutlet weak var notificationButton: UIButton!
    @IBOutlet weak var userNameLabel: UILabel!
    
    var usersReference = Firestore.firestore().collection("users")
    var storageReference = Storage.storage().reference()
    
    let dataBase = Firestore.firestore()
    
    @IBOutlet weak var photoImageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //set stylings for buttons
        Utilities.styleFilledButton(profileButton)
        Utilities.styleFilledButton(imageButton)
        Utilities.styleHollowButton(notificationButton)
        
        // start showing a loading spinner while photo loads
        let spinner = JGProgressHUD()
        spinner.textLabel.text = "Loading"
        spinner.show(in: self.view)
        
        // set corners of image to be rounded
        photoImageView.layer.cornerRadius = 25
        photoImageView.clipsToBounds = true
        photoImageView.contentMode = .scaleToFill
        
        spinner.dismiss()// dismiss the spinner
        
        // MARK: - Gestures
        // set gesture recogniser for right swipe
        
        // sourced from https://stackoverflow.com/questions/44231800/navigate-between-tab-bar-using-swipe-gesture
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
        
        // set gesture recogniser for left swipe
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
        swipeLeft.direction = UISwipeGestureRecognizer.Direction.left
        self.view.addGestureRecognizer(swipeLeft)
    }
    
    @objc func swiped(_ gesture: UISwipeGestureRecognizer) {
        // on a left swipe for the tab bar controller screen which is one less that this
        if gesture.direction == .left {
            if (self.tabBarController?.selectedIndex)! < 3 { // set your total tabs here
                self.tabBarController?.selectedIndex += 1
            } // on a right swipe for the tab bar controller screen which is one greater that this
        } else if gesture.direction == .right {
            if (self.tabBarController?.selectedIndex)! > 0 {
                self.tabBarController?.selectedIndex -= 1
            }
        }
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        let user = Auth.auth().currentUser
        if let user = user {
            
            
            
            let userID = user.uid
            // there isnt a way to collect the users password without hashing protocols
            
            // Read a specific document
            // See: https://firebase.google.com/docs/firestore/query-data/get-data
            dataBase.collection("users")
                .document("\(userID)") // get the user's personal document in the firebase database
                .getDocument { (document, error) in
                    
                    // Check for error
                    if error != nil {
                        self.displayMessage(title: "Error occurred getting your details", message: error!.localizedDescription)
                    }
                    else { // if there are no error's connecting to firebase
                        
                        // Check that this document exists
                        if document != nil && document!.exists {
                            
                            let documentData = document!.data() // if it does take the user's first name
                            if let firstName = documentData!["firstName"] {
                                self.userNameLabel.text = "\(firstName)" // and add it to the firstName text field
                            }
                            
                            if let lastName = documentData!["lastName"] { // take the user's last name
                                self.userNameLabel.text! += " \(lastName)"  // and add it to the lastName text field
                            }
                        }
                        
                    }
                    
                }
            
            let imageCollection = usersReference.document("\(userID)").collection("images")
            imageCollection.document("profilePicture") .getDocument { (document, error) in
                // Check for error
                if error != nil {
                    self.displayMessage(title: "Error occurred getting your details", message: error!.localizedDescription)
                }
                else { // if there are no error's connecting to firebase
                    
                    // Check that this document exists
                    if document != nil && document!.exists {
                        
                        let documentData = document!.data() // if it does take the url stored in the document
                        if let url = documentData!["url"] {
                            
                            // Get a reference to the storage service using the default Firebase App
                            let storage = Storage.storage()
                            
                            // get the picture as referenced by the url from firebase storage and compress it
                            let _ = storage.reference(forURL: url as! String).getData(maxSize: 5 * 1024 * 1024, completion: { (data, error) in
                                if let error = error {
                                    print(error.localizedDescription)
                                    // if there are no errors set the photo image view on screen be the uploaded image
                                } else if let data = data, let image = UIImage(data: data) {
                                    self.photoImageView.image = image
                                    
                                }
                                
                            }
                            
                            )}
                    }}
                
            }
        }
    }
    
    // MARK: - Image Selection
    @IBAction func pickImageAction(_ sender: Any) {
        let controller = UIImagePickerController()
        controller.allowsEditing = false
        controller.delegate = self
        
        // give user options to select photo
        let actionSheet = UIAlertController(title: nil, message: "Select Option:", preferredStyle: .actionSheet)
        
        
        //set photo from camera action
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { action in
            controller.sourceType = .camera
            self.present(controller, animated: true, completion: nil)
        }
        
        
        //set photo from photo library action
        let libraryAction = UIAlertAction(title: "Photo Library", style: .default) { action in
            controller.sourceType = .photoLibrary
            self.present(controller, animated: true, completion: nil)
        }
        
        // set photo from photo album action
        let albumAction = UIAlertAction(title: "Photo Album", style: .default) { action in
            controller.sourceType = .savedPhotosAlbum
            self.present(controller, animated: true, completion: nil)
        }
        // cancel action
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        // add the actions  to the display for the user
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            actionSheet.addAction(cameraAction) // if camera is available add that action
            
        }
        actionSheet.addAction(libraryAction)
        actionSheet.addAction(albumAction)
        actionSheet.addAction(cancelAction)
        
        //present the action choices to the user
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    
    
    //MARK: Saving to storage
    func savePhoto() {
        // guard to ensure photo has been taken
        guard let image = photoImageView.image else {
            displayMessage(title: "Cannot save until a photo has been taken!", message: "Error")
            return
        }
        // guard to ensure user has been logged in
        guard let userID = Auth.auth().currentUser?.uid else {
            displayMessage(title: "Cannot upload image until logged in", message: "Error")
            return
        }
        
        // set the date to be the file name
        let date = UInt(Date().timeIntervalSince1970)
        let filename = "profilePicture.jpg"
        guard let data = image.jpegData(compressionQuality: 0.8) else {
            displayMessage(title: "Image data could not be compressed.", message: "Error")
            return
        }
        // store metadata for image url
        let imageRef = storageReference.child("\(userID)/\(date)")
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpg" // set image type for storage
        imageRef.putData(data, metadata: metadata) { (meta, error) in
            if error != nil { // if there are errors display them
                self.displayMessage(title: "Could not upload image ", message: "Error")
            } else {
                imageRef.downloadURL { (url, error) in
                    guard let downloadURL = url else { // set the image url to a variable
                        print("Download URL not found")
                        return
                    }
                    // store the url under the active users profile picture document
                    let userImageRef = self.usersReference.document("\(userID)")
                    userImageRef.collection("images").document("profilePicture").setData([
                        "url": "\(downloadURL)"
                    ])
                    self.displayMessage(title: "Image updated", message: "Success")
                }
            }
        }
        
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        let fileURL = documentsDirectory.appendingPathComponent(filename) // set app user defaults for the stored file
        
        do {
            try data.write(to: fileURL)
            
            self.navigationController?.popViewController(animated: true)
        } catch {
            displayMessage(title: error.localizedDescription, message: "Error") // catch error
        }
    }
    
    // controlls editing of image view when picture is chosen
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            photoImageView.image = pickedImage //
            savePhoto() // save the photo to storage
        }
        dismiss(animated: true, completion: nil)
    }
    
    // function called when picker is canceled, the view is dismissed
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: Notification Change
    // sourced from https://stackoverflow.com/questions/48796561/how-to-ask-notifications-permissions-if-denied 
    @IBAction func changeNotificationSettings(_ sender: Any) {
        // check if the user has allowed notification settings
        let isRegisteredForRemoteNotifications = UIApplication.shared.isRegisteredForRemoteNotifications
        if !isRegisteredForRemoteNotifications { // if they have not
            // open the settings application to allow them to change the settings
            UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!, options: [:], completionHandler: nil)
        }
    }
    
    // MARK: - Log Out
    @IBAction func LogOut(_ sender: Any) {
        do { // use the firebase library to sign the current user out
            try Auth.auth().signOut()
        } catch { // print an error message is applicable
            print("Log out error: \(error.localizedDescription)")
        }
        
        // navigate back to the storyboard screen with ID authViewController as controlled by the HomeViewController class
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let startViewController = storyBoard.instantiateViewController(withIdentifier: "authViewController") as! HomeViewController
        startViewController.modalPresentationStyle = .fullScreen // display in full screen for swift 5
        self.present(startViewController, animated:true, completion:nil)
        
        
    }
}

