//
//  WeatherViewController.swift
//  Weather
//
//  Created by Mohammad Shayan on 4/16/20.
//  Copyright © 2020 Mohammad Shayan. All rights reserved.
//
// sourced from: https://github.com/mshayanh13/Weather

import UIKit
import MapKit
import JGProgressHUD

class WeatherViewController: UIViewController, CLLocationManagerDelegate {

    //MARK: Local Variables
    @IBOutlet weak var rightNowView: RightNowView! // outlet for the upper view
    @IBOutlet weak var weatherDetailView: WeatherDetailView! // outlet for the lower view
    
    var city = "" // holds the name of the chosen city
    var weatherResult: Result? // holds result of web api query
    var locationManger: CLLocationManager!
    var currentlocation: CLLocation? // holds specified geographical location
    
    var locationLong = ""// holds lat and long values from the MapViewController
    var locationLat = "" 
    
    //MARK: View did Load
    override func viewDidLoad() {
        super.viewDidLoad()
        clearAll() // clear all texts from labels and clear all images
        fetchLocation()
    }
    
    func clearAll() {
        rightNowView.clear() // clear all texts from labels and clear all images from top view
        weatherDetailView.clear() // clear all texts from labels and clear all images from bottom view
    }
    
    //MARK: Update Weather from API
    func getWeather() {
        NetworkService.shared.getWeather(onSuccess: { (result) in
            self.weatherResult = result  // fetch from the web api and store the successful json date results
            
            // json data is recorded at a frequent hourly interval
            self.weatherResult?.sortDailyArray() // sort the weather to display as days of the week
            self.weatherResult?.sortHourlyArray() // sort data to display as houry view
            
            self.updateViews() // update the upper and lower view
            
        }) { (errorMessage) in // if there is an error message in retrieving data display it
            debugPrint(errorMessage)
        }
    }
    
    func updateViews() {
        updateTopView()
        updateBottomView()
    }
    
    func updateTopView() {
        guard let weatherResult = weatherResult else {
            return
        }
        // get weather result for the current city and display this in the upper view
        rightNowView.updateView(currentWeather: weatherResult.current, city: city)
    }
    
    func updateBottomView() {
        guard let weatherResult = weatherResult else {
            return
        }
        
        let title = weatherDetailView.getSelectedTitle()
        // depending on the title of the segmented index i.e hourly or dailyy
        if title == "Today" { // dislay the associated data
            weatherDetailView.updateViewForToday(weatherResult.hourly)
        } else if title == "Weekly" {
            weatherDetailView.updateViewForWeekly(weatherResult.daily)
        }
    }
    
    
    //MARK: get location from lat and long values
    func fetchLocation(){ // get the values taken from MapViewController
        let location = CLLocation(latitude: Double(locationLat)!, longitude: Double(locationLong)!)
        
        self.currentlocation = location // set it to a location type
        
        // set the lat and long variables as double
        let latitude: Double = self.currentlocation!.coordinate.latitude
        let longitude: Double = self.currentlocation!.coordinate.longitude
        
        NetworkService.shared.setLatitude(latitude) // feed data to webAPI call
        NetworkService.shared.setLongitude(longitude)
        
        let geocoder = CLGeocoder() // find location from lat and long in descriptive locatized string
        geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
            if let error = error {
                debugPrint(error.localizedDescription) // print errors
            }
            if let placemarks = placemarks { // break downthe string recturned from geocoder to segments
                if placemarks.count > 0 {
                    let placemark = placemarks[0]
                    if let city = placemark.locality {
                        self.city = city // return the locations city
                    }
                }
            }
        }
        
        getWeather() // get associated whether data for the current city
    }
    
    //MARK: on Refresh
    func getLocation() {
       
        if (CLLocationManager.locationServicesEnabled()) { // if the locations services are enabled

            locationManger = CLLocationManager() // get the users current location
            locationManger.delegate = self
            locationManger.desiredAccuracy = kCLLocationAccuracyBest
            locationManger.requestWhenInUseAuthorization()
            locationManger.requestLocation()
        }
        
    }

    //follows same strucutre as getLocation above
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            self.currentlocation = location
            
            let latitude: Double = self.currentlocation!.coordinate.latitude
            let longitude: Double = self.currentlocation!.coordinate.longitude
            
            NetworkService.shared.setLatitude(latitude)
            NetworkService.shared.setLongitude(longitude)
            
            let geocoder = CLGeocoder()
            geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
                if let error = error {
                    debugPrint(error.localizedDescription)
                }
                if let placemarks = placemarks {
                    if placemarks.count > 0 {
                        let placemark = placemarks[0]
                        if let city = placemark.locality {
                            self.city = city
                        }
                    }
                }
            }
            
            getWeather() // get associated whether data for the current city
        }
    }
    // on fail of retreiving location
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        displayMessage(title: "Error finding location", message: error.localizedDescription)
    }
    
    //MARK: Button Actions
    // on press of the refresh button clear everything and reload the data
    @IBAction func getWeatherTapped(_ sender: UIButton) {
        // start showing a loading spinner while photo loads
        let spinner = JGProgressHUD()
        spinner.textLabel.text = "Loading"
        spinner.show(in: self.view)
        
        clearAll()
        getLocation()
        
        spinner.dismiss() // stop displaying spinner 
        
    }
    // on press of the refresh segmented index clear everything and reload the data
    @IBAction func todayWeeklyValueChanged(_ sender: UISegmentedControl) {
        clearAll()
        updateViews()
    }
}
