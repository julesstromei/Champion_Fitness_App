
//  JTAppleCalendar iOS
//
//  Created by Jay Thomas on 2017-07-11.
//  Adapted by Julian Stromei on 2021-06-01

// https://github.com/patchthecode/JTAppleCalendar
// Github example implemented into code and adapter for use.

import UIKit
import JTAppleCalendar
import FirebaseAuth
import Firebase

class CalendarViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Local Variable initialisation
    @IBOutlet weak var monthLabel: UILabel! // label to dislay month
    @IBOutlet var theView: UIView! // the whole view of the screen
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet var calendarView: JTACMonthView! // the view of the calendar to display the month
    // initialise dictionary
    var calendarDataSource: [String: Any] = [:]
    var formatter: DateFormatter { // initialise date formatter
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MMM-yyyy"
        return formatter
    }
    
    // customizable variables which control the look of the calendar on start up
    var numberOfRows = 6 // variable to set number of rows displayed in calendar month
    var eventCalendar = Calendar.current // the calendar object
    var generateInDates: InDateCellGeneration = .forAllMonths // dates of the month that are in the month itself
    var generateOutDates: OutDateCellGeneration = .tillEndOfGrid // dates from other months that are used to fill the ends of the calendar
    var prePostVisibility: ((CellState, CellView?)->())? // depicts from view cells or days are visible to the user
    var hasStrictBoundaries = true // controls the boundries of the calendar object
    var monthSize: MonthSize? = nil // used to control the size of the calendar
    var prepostHiddenValue = false // controls whether an individual date are hidden or not
    
    // notificaion variables
    let NOTIFICATION_IDENTIFIER = "Champion.App"
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    

    var selectedIndex: Int? // stores the selected event from the tableView
    var myEventList = [Events]() // store a list of events fetched from firebase
    
    // MARK: - View did Load
    override func viewDidLoad() {
        
        super.viewDidLoad() // show all dates in calendar not just the ones belonging to this month
        
        tableView.dataSource = self
        tableView.delegate = self
        
        prePostVisibility = {state, cell in // turn off hidden cells on the calendar month // i.e dates not belonging to this month will be visible
            cell?.isHidden = false
            
        }
        
        // set up calendar colours
        calendarView.backgroundColor =  UIColor(named: "CalendarBackground")
        theView.backgroundColor = UIColor(named: "CalendarBackground")
        
        // add events to calendar and display notifictions if applicable
        addNotification()
        
        // MARK: - Gestures
        // set gesture recogniser for right swipe
        
        
        // set up scrolling gestures
        calendarView.scrollDirection = .horizontal
        calendarView.scrollingMode   = .stopAtEachCalendarFrame // when scrolling stop at each month
        calendarView.showsHorizontalScrollIndicator = false //dont show indicators when scrolling
        
        
        // sourced from https://stackoverflow.com/questions/44231800/navigate-between-tab-bar-using-swipe-gesture
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
        
        // set gesture recogniser for left swipe
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
        swipeLeft.direction = UISwipeGestureRecognizer.Direction.left
        self.view.addGestureRecognizer(swipeLeft)
        
        self.myEventList.removeAll() // on load remove all events from the list
        
        // scroll to and select the current date
        calendarView.scrollToDate(Date())
        calendarView.selectDates([Date()])
        
        self.calendarView.visibleDates {[unowned self] (visibleDates: DateSegmentInfo) in
            self.setupViewsOfCalendar(from: visibleDates)
        }
        
    }
    
    @objc func swiped(_ gesture: UISwipeGestureRecognizer) {
        // on a left swipe for the tab bar controller screen which is one less that this
        if gesture.direction == .left {
            if (self.tabBarController?.selectedIndex)! < 3 { // set your total tabs here
                self.tabBarController?.selectedIndex += 1
            } // on a right swipe for the tab bar controller screen which is one greater that this
        } else if gesture.direction == .right {
            if (self.tabBarController?.selectedIndex)! > 0 {
                self.tabBarController?.selectedIndex -= 1
            }
        }
        
        
    }
    //MARK:  View Will Appear
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        calendarView.reloadData() // reload the calendar
        tableView.reloadData() // reload table data 
    }
    
    //MARK: Button Press Functions
    // scroll to and select todays date on button press
    @IBAction func scrollToToday(_ sender: Any) {
        calendarView.scrollToDate(Date())
        calendarView.selectDates([Date()])
      
        
        
        
    }
    
    //MARK: Calendar Confuguration
    func setupViewsOfCalendar(from visibleDates: DateSegmentInfo) {
        guard let startDate = visibleDates.monthDates.first?.date else {
            return // set the start date of the calendar month
        }
        let month = eventCalendar.dateComponents([.month], from: startDate).month!
        let monthName = DateFormatter().monthSymbols[(month-1) % 12] // convert name of month from date formatter string
        // 0 indexed array
        let year = eventCalendar.component(.year, from: startDate) // set the year
        monthLabel.text = monthName + " " + String(year) // display the month and year in the month label
    }
    
    
    //MARK: Cell Confuguration
    func handleCellConfiguration(cell: JTACDayCell?, cellState: CellState) {
        handleCellSelection(view: cell, cellState: cellState) // handles cell when selected
        handleCellTextColor(view: cell, cellState: cellState) // handles cell text colours
        handleCellEvents(view: cell, cellState: cellState) // handles cell events
        prePostVisibility?(cellState, cell as? CellView) // handles cell visibility
    }
    
    // Function to handle the calendar selection
    func handleCellSelection(view: JTACDayCell?, cellState: CellState) {
        guard let myCustomCell = view as? CellView else {return } // for a day of the month  cell
        // when a cell is selected
        switch cellState.selectedPosition() { // control the color of the cell depending on cell location
        case .full:
            myCustomCell.backgroundColor =  UIColor(named: "CalendarSelect") // colours taken from assets colour set
        case .left:
            myCustomCell.backgroundColor = UIColor(named: "CalendarSelect")
        case .right:
            myCustomCell.backgroundColor = UIColor(named: "CalendarSelect")
        case .middle:
            myCustomCell.backgroundColor = UIColor(named: "CalendarSelect")
        case .none:
            myCustomCell.backgroundColor = UIColor(named: "CalendarBackground")
            
        }
        
        
    }
    
    // Function to handle the text color of the calendar
    func handleCellTextColor(view: JTACDayCell?, cellState: CellState) {
        guard let myCustomCell = view as? CellView  else {
            return
        }
        // do not hide any cells
        prePostVisibility = {state, cell in
            cell?.isHidden = false
            
            // if the cell belongs to the current month
            if state.dateBelongsTo == .thisMonth {
                if cellState.isSelected { // if it is selected
                    myCustomCell.dayLabel.textColor = .white // make the text colour white
                } else { // if it is not selected and from this month assign it to thee insideMonthText colour set
                    cell?.dayLabel.textColor =  UIColor(named: "insideMonthText") }
            } else { // if the date doesnt belong to this month
                if cellState.isSelected { // if its selected make it white
                    myCustomCell.dayLabel.textColor = .white
                }else { // if it isnt selected assigns its color from the month text colour set in the assets folder
                    cell?.dayLabel.textColor =  UIColor(named: "outsideMonthText")
                    
                }
            }
        }
        
        myCustomCell.isHidden = cellState.dateBelongsTo != .thisMonth // cells are not configured if they are outside of the users view,
        // reduces loading times
        
    }
    
    func handleCellEvents(view: JTACDayCell?, cellState: CellState) { // handles adding events to the calendar
        guard let myCustomCell = view as? CellView  else {
            return
        }
        // all event icons are turned off
        myCustomCell.dotView.isHidden = true
        
        guard let userID = Auth.auth().currentUser?.uid else {
            returnHome()  // display error and return user to re authenticate themselves if they have logged out
            
            
            return
        }
        
        // take the date from the each cell
        let dateString = formatter.string(from: cellState.date)
        
        let usersReference = Firestore.firestore().collection("users")
        // under the user's personal file collection in firebase
        let userRef = usersReference.document("\(userID)")
        
        userRef.collection("events") // get all current users events
            .getDocuments { (snapshot, error) in
                if error != nil { // Detect for errors, use completion parameter
                    self.displayMessage(title: "Could not retrieve your events", message: "Error")
                }
                
                if error == nil && snapshot != nil { // if the doc exists and there are no errors
                    
                    for document in snapshot!.documents {
                        
                        self.calendarDataSource = document.data() // update the data source to include these events
                        if let eventDate = self.calendarDataSource["eventDate"] {
                            if dateString == "\(eventDate)" { // if the event is for this cells date
                                myCustomCell.dotView.isHidden = false // add a visible dot to the view
                            }
                        }
                        
                    }
                    
                }
            }
        
        
    }
    
    
    
    
    
    //MARK: Cell Events and notifications
    
    func addNotification(){
        let today = Date() // store todays date
        let todayString = (formatter.string(from: today)) // convert to string
        
        guard let userID = Auth.auth().currentUser?.uid else {
            displayMessage(title: "Cannot create event until logged in", message: "You have been inactive for too long, redirecting you to log in")
            // else return them to the landing page for authenitifcation
            let authViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.authViewController) as? HomeViewController
            
            self.view.window?.rootViewController = authViewController
            self.view.window?.makeKeyAndVisible()
            
            return
        }
        
        
        let usersReference = Firestore.firestore().collection("users")
        // under the user's personal file collection in firebase
        let userRef = usersReference.document("\(userID)")
        
        userRef.collection("events").whereField("eventDate", isEqualTo: todayString).getDocuments { (snapshot, error) in // find the events that are on toady
            if error == nil && snapshot != nil {
                
                for document in snapshot!.documents {
                    
                    let documentData = document.data()
                    // get todays events data
                    let eventName = documentData["eventName"] as! String
                    
                    // add a notification
                    guard self.appDelegate.notificationsEnabled else {
                        print("Notifications disabled")
                        return
                    }
                    
                    let content = UNMutableNotificationContent()
                    
                    // let the content title show the value from the key value pair in the dataSource
                    content.title = "Event \(eventName) on today"
                    content.body = "Events starting today: \(todayString)" // display the days date for context
                    
                    // display after 1 second
                    let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
                    
                    let request = UNNotificationRequest(identifier: self.NOTIFICATION_IDENTIFIER, content: content, trigger: trigger)
                    
                    UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
                }
                
            }
        }
        
        
        
    }
    
    
    // function effects the way that the calendar transitions to new month
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        let visibleDates = calendarView.visibleDates()
        // anchor the end date of the previous month to be the start of the next, so that the month starts on the correct day of the week
        calendarView.viewWillTransition(to: .zero, with: coordinator, anchorDate: visibleDates.monthDates.first?.date)
        
    }
    
    
    // MARK: - Table view data source
    
    func populateTableData(todayString: String) {
        
        self.myEventList.removeAll()
        
        guard let userID = Auth.auth().currentUser?.uid else {
           returnHome() // return the user to log in
            return
        }
        
        let usersReference = Firestore.firestore().collection("users")
        // under the user's personal file collection in firebase
        let userRef = usersReference.document("\(userID)")
        
        
        userRef.collection("events").whereField("eventDate", isEqualTo: todayString).getDocuments { (snapshot, error) in // if find the events for the currently selected calendar day
            if error == nil && snapshot != nil {
                 // if there are no errors and the doc exists
                for document in snapshot!.documents {
                    
                    // save the event data
                    let documentData = document.data()
                    let eventName = documentData["eventName"] as! String
                    let eventDate = documentData["eventDate"] as! String
                    let eventDescription = documentData["eventDescription"] as! String
                    
                    // if the event has a location create an event of event class with a location
                    if let locationName = documentData["locationName"]{
                        let myEvents = Events(name: eventName, date: eventDate, description: eventDescription, locationName: locationName as! String)
                        self.myEventList.append(myEvents) //add this event to the event list
                    }
                    else { // just create an event without the location
                        let myEvents = Events(name: eventName, date: eventDate, description: eventDescription)
                        self.myEventList.append(myEvents) // append this to the list
                    }
                    
                    
                    DispatchQueue.main.async {
                        self.tableView.reloadData() // reload the table view to display the event list
                    }
                }
            }
            
        }
    }
    //MARK: Set up Table View
    // section holds event data
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myEventList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // for the detail cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "detailCell", for: indexPath) as! ScheduleTableViewCell
        
        
        let cellDetail = myEventList[indexPath.row]
        cell.textLabel?.text = cellDetail.eventName // set the cell name to be the event name
        
        if cellDetail.locationName != nil {
            cell.locationMarker.image = UIImage(systemName: "mappin") // if the event has a location, and a pin icon to the table cell
        }
        else{
            cell.locationMarker.image = nil
        }
        cell.detailTextLabel?.text = cellDetail.eventDescription // for display purposes only display the event date in the detail text label
        
        return cell
        
        
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete { // when deleteing the cell
            let cellDetail = myEventList[indexPath.row]
            let eventRef = cellDetail.eventName! // get the name of the cell selected
            
            guard let userID = Auth.auth().currentUser?.uid else { // determine if user is still logged in
              returnHome() // return the user to log in
                return
            }
            
            let usersReference = Firestore.firestore().collection("users")
            // under the user's personal file collection in firebase
            let userRef = usersReference.document("\(userID)")
            
            // Delete a document
            // See: https://firebase.google.com/docs/firestore/manage-data/delete-data
            
            userRef.collection("events") // delete the event from firebase
                .document("\(eventRef)")
                .delete { (error) in
                    if error != nil { // Detect for errors, use completion parameter
                        self.displayMessage(title: "Could not delete event", message: error!.localizedDescription)
                    }
                    else { // succeeds
                        self.displayMessage(title: "Event deleted", message: "\(eventRef) has been deleted")
                    }
                }
            
            
            
            calendarView.reloadData() // reload the calendar
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedIndex = indexPath.row // if a cell is selected go the the add event screen
        performSegue(withIdentifier: "editEventSegue", sender: nil)    }
    
    
    // MARK: - Navigation
    
    
    // prepare mapview controller with locationDelegate
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "editEventSegue" { // if the user has tapped on a cell
            let destination = segue.destination as! AddEventViewController
            let cellDetail = myEventList[selectedIndex!] // send the name of the event to the destination contoller
            destination.exisistingEventName = cellDetail.eventName
        }

    }
    
    func returnHome() { // display error and return user to re authenticate themselves if they have logged out
        displayMessage(title: "Cannot create event until logged in", message: "You have been inactive for too long, redirecting you to log in")
        // else return them to the landing page for authenitifcation
        let authViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.authViewController) as? HomeViewController
        
        self.view.window?.rootViewController = authViewController
        self.view.window?.makeKeyAndVisible()
    }
    
    
    
}

// https://github.com/patchthecode/JTAppleCalendar
// Github example implemented into code and adapter for use.

// MARK: JTAppleCalendarDelegate
extension CalendarViewController: JTACMonthViewDelegate, JTACMonthViewDataSource {
    func configureCalendar(_ calendar: JTACMonthView) -> ConfigurationParameters {
        
        //format timezone
        formatter.timeZone = eventCalendar.timeZone
        formatter.locale = eventCalendar.locale
        
        // inialise start and end dates of the calendar
        let startDate = formatter.date(from: "01-jan-2018")!
        let endDate = formatter.date(from: "01-jan-2024")!
        
        // configure calendar as per constraints listed in local variable initialisation
        let parameters = ConfigurationParameters(startDate: startDate,
                                                 endDate: endDate,
                                                 numberOfRows: numberOfRows,
                                                 calendar: eventCalendar,
                                                 generateInDates: generateInDates,
                                                 generateOutDates: generateOutDates,
                                                 firstDayOfWeek: .sunday,
                                                 hasStrictBoundaries: hasStrictBoundaries)
        return parameters
    }
    
    //handles day number for each month
    func configureVisibleCell(myCustomCell: CellView, cellState: CellState, date: Date, indexPath: IndexPath) {
        myCustomCell.dayLabel.text = cellState.text
        handleCellConfiguration(cell: myCustomCell, cellState: cellState)
        
    }
    
    //configures days to be displayed
    func calendar(_ calendar: JTACMonthView, willDisplay cell: JTACDayCell, forItemAt date: Date, cellState: CellState, indexPath: IndexPath) {
        let myCustomCell = cell as! CellView
        configureVisibleCell(myCustomCell: myCustomCell, cellState: cellState, date: date, indexPath: indexPath)
    }
    
    //  handles cell cells in each calendar month as individual days
    func calendar(_ calendar: JTACMonthView, cellForItemAt date: Date, cellState: CellState, indexPath: IndexPath) -> JTACDayCell {
        let myCustomCell = calendar.dequeueReusableCell(withReuseIdentifier: "CellView", for: indexPath) as! CellView
        configureVisibleCell(myCustomCell: myCustomCell, cellState: cellState, date: date, indexPath: indexPath) // sets visibility of day
        return myCustomCell
    }
    //handles deselection of dates 
    func calendar(_ calendar: JTACMonthView, didDeselectDate date: Date, cell: JTACDayCell?, cellState: CellState, indexPath: IndexPath) {
        handleCellConfiguration(cell: cell, cellState: cellState)
    }
    
    // handles selection of date
    func calendar(_ calendar: JTACMonthView, didSelectDate date: Date, cell: JTACDayCell?, cellState: CellState, indexPath: IndexPath) { // when a date is selected
        let dateString = formatter.string(from: cellState.date) // take its date and convert it to a strbg
        populateTableData(todayString: dateString) // populate the table with events from this date
        handleCellConfiguration(cell: cell, cellState: cellState) // reload the calendar
        tableView.reloadData() // reload the table
    }
    
    func calendar(_ calendar: JTACMonthView, didScrollToDateSegmentWith visibleDates: DateSegmentInfo) {
        // not used but needed function stub
    }
    // controls calendar scroll
    func calendar(_ calendar: JTACMonthView, willScrollToDateSegmentWith visibleDates: DateSegmentInfo) {
        setupViewsOfCalendar(from: visibleDates)
    }
}
