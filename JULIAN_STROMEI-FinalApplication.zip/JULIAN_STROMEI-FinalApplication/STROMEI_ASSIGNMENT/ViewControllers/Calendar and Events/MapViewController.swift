//
//  MapViewController.swift
//  Lecture07-02-02
//
//  Created by Michael Wybrow on 16/4/21.
// adapted by Julian Stromei

import UIKit
import MapKit
import JGProgressHUD

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate, DatabaseListener {
    
    // MARK: - Local Variable initialisation
    @IBOutlet weak var locationBarButtonItem: UIBarButtonItem!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var confirmButton: UIButton!
    
    @IBOutlet weak var weatherButton: UIButton!
    weak var locationDelegate: AddLocationDelegate? // used for sending location information back to the delegate
    
    var LocationName: String?
    let locationManager = CLLocationManager()
    
    weak var databaseController: DatabaseProtocol?
    var listenerType: ListenerType = .all
    
    // used to store location information for delegation
    var LocationLat: String = ""
    var LocationLong: String = ""
    var LocationAddress: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // set stylings ofthe button from utilities .swift
        Utilities.styleFilledButton(confirmButton)
        Utilities.styleFilledButton(weatherButton)
        
        displayMessage(title: "Add Location", message: "Press on the screen to add a location to your event")
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        databaseController = appDelegate.databaseController
        
        locationManager.delegate = self
        mapView.delegate = self
        
        confirmButton.alpha = 0 // set the confirm button to not be visible until a location has been chosen
        weatherButton.alpha = 0// set the weather button to not be visible until a location has been chosen
        
        let longTapGesture = UILongPressGestureRecognizer(target: self, action: #selector(longTap(sender:))) // add a long touch recogniser
        mapView.addGestureRecognizer(longTapGesture)
        
        let monashClayton = CLLocationCoordinate2D(latitude: -37.9108516, longitude: 145.1355282) // initialise a starting location
        // initalise the size of the starting view based off cebter starting point monashClayton
        let monashRegion = MKCoordinateRegion(center: monashClayton, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(monashRegion, animated: true)
        
        // initialise a location to become an annotation
        let theatreLG02 = CLLocationCoordinate2D(latitude: -37.9095225, longitude: 145.1354168)
        
        //add the annotation
        let theatreAnnotation = MKPointAnnotation()
        theatreAnnotation.coordinate = theatreLG02
        theatreAnnotation.title = "Theatre LG.02"
        theatreAnnotation.subtitle = "FIT3178 wonders!"
        mapView.addAnnotation(theatreAnnotation)
    }
    
    
    //MARK: View Did Appear and will Disappear
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        
        
        databaseController?.addListener(listener: self)
        // determine whether the app has been granted access to your location
        let status = locationManager.authorizationStatus
        if status == .notDetermined { // if it is not determined, request it
            locationManager.requestWhenInUseAuthorization()
        }
        else { // allows access when in use
            locationBarButtonItem.isEnabled = (status == .authorizedWhenInUse)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        databaseController?.removeListener(listener: self) // remove database listener
    }
    
    //MARK: Location authorization
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus // set the authorization status
        locationBarButtonItem.isEnabled = (status == .authorizedWhenInUse) // if location services are enabled, allow access to the bar button for location
        if mapView.showsUserLocation && status != .authorizedWhenInUse {
            // If location shown and no longer authorised, toggle off.
            toggleLocationTracking(self)
        }
    }
    //MARK: update map
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {//  set up the map view area
        var region = MKCoordinateRegion()
        region.center = userLocation.coordinate
        region.span = mapView.region.span
        mapView.setRegion(region, animated: true)
    }
    
    
    @IBAction func mapTypeSegmentControlChanged(_ segmentedControl: UISegmentedControl) { // depending on the bar button selection update the map
        switch segmentedControl.selectedSegmentIndex {
        case 0:
            mapView.mapType = .standard
        case 1:
            mapView.mapType = .satellite
        case 2:
            mapView.mapType = .hybrid
        default:
            mapView.mapType = .standard
        }
    }
    
    @IBAction func toggleLocationTracking(_ sender: Any) { //  the upper right bar button on tap
        mapView.showsUserLocation = !mapView.showsUserLocation // show the users location
        let iconName = (mapView.showsUserLocation) ? "location.fill" : "location"
        locationBarButtonItem.image = UIImage(systemName: iconName)
    }
    
    
    //MARK: Adding Annotations
    //Sourced from: https://stackoverflow.com/questions/40844336/create-long-press-gesture-recognizer-with-annotation-pin
    // on a long tap
    @objc func longTap(sender: UIGestureRecognizer){
        
        if sender.state == .began {
            let locationInView = sender.location(in: mapView)
            // find where on the user pressed and convert it to co-ordinates
            let locationOnMap = mapView.convert(locationInView, toCoordinateFrom: mapView)
            // remove all other annotations
            mapView.removeAnnotations(mapView.annotations)
            addAnnotation(location: locationOnMap) // add the location as an annotation
            confirmButton.alpha = 1 // make the confirm location button visible
            weatherButton.alpha = 1
        }
    }
    
    
    // Sourced from: https://stackoverflow.com/questions/40844336/create-long-press-gesture-recognizer-with-annotation-pin
    func addAnnotation(location: CLLocationCoordinate2D){
        // create an annontation
        let annotation = MKPointAnnotation()
        annotation.coordinate = location // set its position to the location specified in the parametres
        LocationLat = "\(location.latitude)"
        LocationLong = "\(location.longitude)"
        getAddressFromLatLon(pdblLatitude: LocationLat, withLongitude: LocationLong) // convert location co-ordinates to an address
        
        // start showing a loading spinner while photo loads
        let spinner = JGProgressHUD()
        spinner.textLabel.text = "Loading"
        spinner.show(in: self.view)
        
        // as the function will return before an address will be generated, wait for 0.2 seconds to retrieve the address from the web
        let _ = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: false) { (timer) in
            annotation.title = self.LocationAddress // set the annotations title to the location address
            self.mapView.addAnnotation(annotation) // put the location on the map
        }
        spinner.dismiss() // stop showing the spinner
    }
    
    // Sourced from: https://stackoverflow.com/questions/41358423/swift-generate-an-address-format-from-reverse-geocoding
    func getAddressFromLatLon(pdblLatitude: String, withLongitude pdblLongitude: String) {
        var center : CLLocationCoordinate2D = CLLocationCoordinate2D() // find centre
        var addressString = "" // initialise the string so it does not return an optional
        let lat: Double = Double("\(pdblLatitude)")! // convert string to double
        
        let lon: Double = Double("\(pdblLongitude)")! // convert string to double
        
        // convert the co-ordinates to a Geocoder location
        let ceo: CLGeocoder = CLGeocoder()
        center.latitude = lat
        center.longitude = lon
        
        let loc: CLLocation = CLLocation(latitude:center.latitude, longitude: center.longitude)
        
        // dissect the geocoder location down to its components, i.e suburb, street, country
        ceo.reverseGeocodeLocation(loc, completionHandler:
                                    {(placemarks, error) in
                                        if (error != nil)
                                        {
                                            print("reverse geodcode fail: \(error!.localizedDescription)")
                                        }
                                        let pm = placemarks! as [CLPlacemark]
                                        
                                        if pm.count > 0 {
                                            let pm = placemarks![0]
                                            
                                            
                                            if pm.subLocality != nil {
                                                addressString = addressString + pm.subLocality! + ", "
                                            }
                                            if pm.thoroughfare != nil {
                                                addressString = addressString + pm.thoroughfare! + ", "
                                            }
                                            if pm.locality != nil {
                                                addressString = addressString + pm.locality! + ", "
                                            }
                                            if pm.country != nil {
                                                addressString = addressString + pm.country! + ", "
                                            }
                                            if pm.postalCode != nil {
                                                addressString = addressString + pm.postalCode! + " "
                                            }
                                            print(addressString)
                                            self.LocationAddress = addressString // set the address string to thelocation address variable
                                            
                                        }
                                        
                                    })
        
    }
    
    
    // MARK: Confirm Location
    
    // Repurposed from https://programmingwithswift.com/add-uitextfield-to-uialertcontroller-with-swift/
    @IBAction func onConfirmTap(_ sender: Any) {
        let alert = UIAlertController(title: "Confirm Event Location", message: "Enter a Name for your location", preferredStyle: .alert)
        
        // add cancel button to alert
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        // add text field to alert controller
        alert.addTextField(configurationHandler: { textField in
            textField.text = self.LocationAddress
        })
        
        //add done button, on press of the done button
        alert.addAction(UIAlertAction(title: "Done", style: .default, handler: { action in
            
            // check if the textfield has text
            guard let locationTitle = alert.textFields?.first!.text else {
                // if not display this message and return
                self.displayMessage(title: "Enter a Name", message: "Name cannot be blank")
                return
            }
            if locationTitle == "" {
                // if not display this message and return
                self.displayMessage(title: "Enter a Name", message: "Name cannot be blank")
                return
            }
            // add to core data
            let _ = self.databaseController?.addLocation(name: locationTitle, longitude: self.LocationLong, latitude: self.LocationLat)
            
            // if a delegate has been passed to the MapViewController class
            if(self.locationDelegate != nil) {
                self.locationDelegate?.addLocation(locationName: locationTitle, locationLat: self.LocationLong, locationLong: self.LocationLat)
            } // update the delegate
            
            
            self.navigationController?.popViewController(animated: true) // return to the lower level view in the stack
        

        }))
        
        self.present(alert, animated: true)
        
    }
    
    // MARK: Weather Button Pressed
    
    @IBAction func weatherPressed(_ sender: Any) {
        performSegue(withIdentifier: "viewWeather", sender: nil)
    }
    
    
    
    // MARK: - Navigation
    
    
    // prepare mapview controller with locationDelegate
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "viewWeather" { // if the user has tapped the weather button
            let destination = segue.destination as! WeatherViewController // send the location of the annotation to the weatherViewController
            destination.locationLong = LocationLong
            destination.locationLat = LocationLat
        }

    }
    
    // MARK: Database listener
    func onLocationChange(change: DatabaseChange, eventLocation: Location) {
        // Do nothing not called
    }
    
}



