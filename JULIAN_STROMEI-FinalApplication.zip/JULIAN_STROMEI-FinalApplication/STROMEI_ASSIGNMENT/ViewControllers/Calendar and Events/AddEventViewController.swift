//
//  AddEventViewController.swift
//  STROMEI_ASSIGNMENT
//
//  Created by Julian Stromei on 4/5/21.
//

import UIKit
import Firebase
import FirebaseAuth


class AddEventViewController: UIViewController, AddLocationDelegate{
    
    // MARK: - Local Variable initialisation
    //set up reference to firebase collection
    let usersReference = Firestore.firestore().collection("users")
    
    //outlet connection for text field
    @IBOutlet weak var eventNameTextField: UITextField!
    @IBOutlet weak var addDateTextField: UITextField!
    @IBOutlet weak var eventDescriptionTextField: UITextField!
    
    @IBOutlet weak var locationLabel: UILabel!
    // outlet connections for buttons
    @IBOutlet var locationButton: UIButton!
    @IBOutlet var groupButton: UIButton!
    
    // initialie date picker
    private var datePicker: UIDatePicker?
    
    weak var databaseController: DatabaseProtocol?
    let NOTIFICATION_IDENTIFIER = "Champion.App"
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    // set variables to hold location information from delegation
    var eventLocationName : String!
    var eventLocationLat : String!
    var eventLocationLong : String!
    
    let dateFormatter = DateFormatter()
    
    var exisistingEventName: String! // event name variable passed from calendarViewController to edit event
    
    // MARK: - View did Load
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // set textfield delegates so that the return button can be pressed to remove the ui keyboard
        eventNameTextField.delegate = self // set delegate
        addDateTextField.delegate = self // set delegate
        eventDescriptionTextField.delegate = self // set delegate
        
        // add stylings for the following objects
        Utilities.styleTextField(eventNameTextField)
        Utilities.styleFilledButton(locationButton)
        Utilities.styleFilledButton(groupButton)
        
        databaseController = appDelegate.databaseController
        datePicker = UIDatePicker()
        
        // for iOS 14, you must specify the style and sizetoFit, otherwise it does not display correctly.
        if #available(iOS 14, *){
            datePicker?.preferredDatePickerStyle = .wheels
            datePicker?.sizeToFit()
        }
        // create a UI datepicker through a toolbar
        createDatePicker()
        
        // if the app has been passed an event from the CalendarView Controller
        if exisistingEventName != nil {
            eventNameTextField.text = exisistingEventName
            // check if a user is logged in
            guard let userID = Auth.auth().currentUser?.uid else {
                returnHome() // if not return to log in
                
                return
            }
            
            
            // under the user's personal file collection in firebase
            let userRef = usersReference.document("\(userID)")
            
            // establish refence to users event collection in the firebase collection
            let eventRef = userRef.collection("events").document("\(exisistingEventName!)")
            eventRef.getDocument { (document, error) in // get the event document passed by the Calendar ViewController
                // Check for error
                if error != nil { // display errors if there are any
                    self.displayMessage(title: "Error loading your Event ", message: "Error")
                }
                else {
                    
                    // Check that this document exists
                    if document != nil && document!.exists {
                        
                        let documentData = document!.data()
                        
                        // set the textfields to load the associated event data from the firebase document
                        self.eventNameTextField.text = documentData!["eventName"] as! String
                        self.eventDescriptionTextField.text = documentData!["eventDescription"] as! String
                        self.addDateTextField.text = documentData!["eventDate"] as! String
                        if let eventLocation = documentData!["locationName"] { // if the event has a location
                            self.locationLabel.text = "\(eventLocation)" // and add it to the location label
                        }
                        // if youre editing an event change the nav title
                        self.navigationItem.title = "Edit Event"
                        
                    }
                    
                    
                }
                
            }
            
        }
        
    }
    // MARK: - Handle Date Picker
    //  Repurposed from: https://www.youtube.com/watch?v=8NngJrVFfUw
    func createDatePicker() {
        let toolbar = UIToolbar()
        // ensures toolbar fits screen size
        toolbar.sizeToFit()
        
        //bar button contains done button to confirm date selection
        let donebtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([donebtn], animated: true)
        
        
        addDateTextField.inputAccessoryView = toolbar
        addDateTextField.inputView = datePicker
        
        //date picker mode
        datePicker?.datePickerMode = .date
    }
    
    
    // Repurposed from: https://www.youtube.com/watch?v=8NngJrVFfUw
    // when the done button is pressed
    @objc func donePressed(){
        // format date retrieved from date picker
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MMM-yyyy"
        
        // convert date to string for use in JTAppleCalendar library
        // place inside text field
        addDateTextField.text = formatter.string(from: datePicker!.date)
        self.view.endEditing(true)
    }
    
    // MARK: - Saving event data
    // when the add event button is pressed
    @IBAction func addEvent(_ sender: Any) {
        
        // ensure all text fields have been filled out
        if eventNameTextField.text != "" && addDateTextField.text != ""  && eventDescriptionTextField.text != ""  {
            let name = eventNameTextField.text!
            let date = addDateTextField.text!
            let description = eventDescriptionTextField.text!
            
            // save event data to core data
            let _ = databaseController?.addEvent(name: name, description: description, date: date)
            
            // save to firebase
            
            // ensure that a valid user has been logged in
            guard let userID = Auth.auth().currentUser?.uid else {
                returnHome() // return them to the home controller
                
                return
            }
            
            // under the user's personal file collection in firebase
            let userRef = usersReference.document("\(userID)")
            // save the following event data in an event collection folder,
            // save it as a document named after the event name, merge with an existing document by the same name if it exists
            userRef.collection("events").document("\(name)").setData(["eventName" : "\(name)",
                                                                      "eventDate":"\(date)",
                                                                      "eventDescription":"\(description)"], merge:true){ [self] (error) in
                // if an error occurs present an error message in the local language, here it should be english
                if error != nil {
                    self.displayMessage(title: "Error occurred writing to Database", message: error!.localizedDescription)
                    
                } // if an error has not occured,
                else { // if the app has been passed location information through delegation, add the location information to the document
                    if self.eventLocationName != nil {
                        userRef.collection("events").document("\(name)").setData(["locationName" : "\(self.eventLocationName!)",
                                                                                  "locationLatitude":"\(self.eventLocationLat!)",
                                                                                  "locationLongitude":"\(self.eventLocationLong!)"], merge:true){ (error) in
                            // if this causes an error display it in the same fashion as above.
                            if error != nil {
                                self.displayMessage(title: "Error occurred writing to Database", message: error!.localizedDescription)
                                
                            }
                        }
                    }
                    // regardless of whether a location was added or not, if an event is successfully added to firebase.
                    // if local notifications have been enabled by the user
                    guard appDelegate.notificationsEnabled else {
                        print("Notifications disabled")
                        return
                    }
                    // create a local notification
                    let content = UNMutableNotificationContent()
                    // if the event is being created set the title to say it was created
                    if exisistingEventName == nil {
                        content.title = "Event \(name) created: "}
                    else {   // if the event is being updated set the title to say it was updated
                        content.title = "Event \(name) updated: "}
                    
                    content.body = "Event will start at \(date)"
                    
                    // display it after 3 seconds.
                    let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 3, repeats: false)
                    
                    
                    let request = UNNotificationRequest(identifier: NOTIFICATION_IDENTIFIER, content: content, trigger: trigger)
                    // display the request without a completion handler, to allow for users to complete other activities un-consequentially
                    UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
                    // return to lower level view in the stack
                    navigationController?.popViewController(animated: true)
                    return
                }
                
                // if the fields have not been filled in
                // duisplay the relevent error messages
                var errorMsg = "Please ensure all fields are filled:\n"
                
                if eventNameTextField.text == "" {
                    errorMsg += "- Must provide a name\n"
                }
                if eventDescriptionTextField.text == "" {
                    errorMsg += "- Must provide a description"
                }
                if addDateTextField.text == "" {
                    errorMsg += "- Must provide a date"
                }
                
                displayMessage(title: "Not all fields filled", message: errorMsg)
            }
            
            
            // Delete a document
            // See: https://firebase.google.com/docs/firestore/manage-data/delete-data
            
            // docuements in firebase are stored under their event names
            // if a user edited an event and changed its name firebase would create a new event
            // hence we need to delete the duplicate event from firebase
            if eventDescriptionTextField.text != exisistingEventName && exisistingEventName != nil {
                userRef.collection("events")
                    .document("\(exisistingEventName)")
                    .delete { (error) in
                        if error != nil { // Detect for errors, use completion parameter
                            self.displayMessage(title: "Error occured in overwriting event", message: "Error")
                        }
                        
                    }
            }
            
        }
        // if the text fields are not filled in
        else {
            displayMessage(title: "Misssing Fields", message: "Please enter in all fields before submitting")
            return
        }
    }
    
    
    
    // MARK: - Navigation
    
    // prepare mapview controller with locationDelegate
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "locationSegue" {
            let destination = segue.destination as! MapViewController
            destination.locationDelegate = self
        }
        
        else if segue.identifier == "inviteGroupSegue"{ // if a user is distributing event invites
            let eventName = eventNameTextField.text ?? "" // save current event details give defaults in textfields are empty 
            let eventDate = addDateTextField.text ?? ""
            let locationName = locationLabel.text ?? ""
            let eventDescription = eventDescriptionTextField.text ?? ""
            var eventInvite: String!
            
            if locationLabel.text != "" { // if the event has a location
                // send them details with the location
                eventInvite = "I'm Inviting you all to my event: \(eventName). It will be held on \(eventDate) at: \(locationName). Here is the event details: \(eventDescription)."
            }
            else{ // if the event does not have a location
                // send them an invite without a location detail
                eventInvite = "I'm Inviting you all to my event: \(eventName). It will be held on \(eventDate). Here is the event details: \(eventDescription)."
            }
            let destination = segue.destination as! MyChannelsTableViewController
            destination.eventDetailMessage = eventInvite
        }
    }
    
    
    func returnHome () {
        // display error message
        displayMessage(title: "Cannot create event until logged in", message: "You have been inactive for too long, redirecting you to log in")
        //  return them to the landing page for authenitifcation
        let authViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.authViewController) as? HomeViewController
        
        self.view.window?.rootViewController = authViewController
        self.view.window?.makeKeyAndVisible()
    }
    
    // MARK: - Delegation
    // delegate function to store the return values from the Location selection in MapViewController
    func addLocation(locationName: String, locationLat: String, locationLong: String) {
        eventLocationName = locationName
        eventLocationLong = locationLong
        eventLocationLat = locationLat
        locationLabel.text = locationName
    }
    
}

// enables keyboard to be dismissed for textfields that follow this delegation.
extension AddEventViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder() // dismiss keyboard
        return true
    }
}
