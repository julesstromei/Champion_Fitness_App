//
//  Event+CoreDataClass.swift
//  STROMEI_ASSIGNMENT
//
//  Created by user185645 on 6/6/21.
//
//

import Foundation
import CoreData

@objc(Event)
public class Event: NSManagedObject {

}
