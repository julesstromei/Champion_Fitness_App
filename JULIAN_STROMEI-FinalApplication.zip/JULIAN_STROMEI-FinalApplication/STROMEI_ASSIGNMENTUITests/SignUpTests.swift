//
//  SignUpTests.swift
//  STROMEI_ASSIGNMENTUITests
//
//  Created by user185645 on 6/15/21.
//

import XCTest

class SignUpTests: XCTestCase {

    override func setUpWithError() throws {

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
// test sign up procedure to see what happens if no fields are entered
    func testNoInputforUserCreation() throws {
        
        let app = XCUIApplication()
        app.launch()
        
        app/*@START_MENU_TOKEN@*/.staticTexts["Sign Up"]/*[[".buttons[\"Sign Up\"].staticTexts[\"Sign Up\"]",".staticTexts[\"Sign Up\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        app.buttons["Sign Up"].tap()
        
        let errorLabel = app.staticTexts["Please fill in all fields."]
        
        XCTAssertEqual(errorLabel.label, "Please fill in all fields.")

        
    }
    
    

}
