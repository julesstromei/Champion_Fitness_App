//
//  Location+CoreDataProperties.swift
//  STROMEI_ASSIGNMENT
//
//  Created by user185645 on 6/6/21.
//
//

import Foundation
import CoreData


extension Location {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Location> {
        return NSFetchRequest<Location>(entityName: "Location")
    }

    @NSManaged public var locationLatitude: String?
    @NSManaged public var locationLongitude: String?
    @NSManaged public var locationName: String?

}

extension Location : Identifiable {

}
