//
//  Location+CoreDataClass.swift
//  STROMEI_ASSIGNMENT
//
//  Created by user185645 on 6/6/21.
//
//

import Foundation
import CoreData

@objc(Location)
public class Location: NSManagedObject {

}
